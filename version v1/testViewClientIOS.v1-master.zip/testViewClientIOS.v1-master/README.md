testViewClientIOS.v1
====================
This is the first version with tag/activity/contact model and related views. It could be used for furture development.

Will start build on v2 as a refresh start to include only necessary functions for the first version of Remolet.
