//
//  TVTagsMultiViewController.m
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTagsMultiNonTabViewController.h"

@interface TVTagsMultiNonTabViewController ()

@end

@implementation TVTagsMultiNonTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.positionY = 0.0;
        self.extraHeightReduce = 44.0;
        self.myEntityName = @"TVTag";
        self.cellTitle = @"tagName";
        self.tempAddedRowsIsOn = NO;
        self.startWithEditMode = YES;
        self.dataSourceIsForTargetTable = NO;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
