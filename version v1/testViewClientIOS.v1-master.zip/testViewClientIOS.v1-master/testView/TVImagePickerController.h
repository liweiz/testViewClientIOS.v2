//
//  TVImagePickerController.h
//  testView
//
//  Created by Liwei on 2013-07-28.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVImagePickerController : UIImagePickerController

@end
