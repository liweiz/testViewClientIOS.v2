//
//  TVLabel.h
//  testView
//
//  Created by Liwei on 11/10/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVLabel : UILabel

@end
