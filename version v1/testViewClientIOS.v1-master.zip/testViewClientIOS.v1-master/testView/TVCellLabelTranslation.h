//
//  TVCellLabelTranslation.h
//  testView
//
//  Created by Liwei on 2013-08-25.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TVCellLabel.h"

@interface TVCellLabelTranslation : TVCellLabel

@end
