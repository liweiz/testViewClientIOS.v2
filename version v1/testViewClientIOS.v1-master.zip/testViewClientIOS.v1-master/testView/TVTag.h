//
//  TVTag.h
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "TVBase.h"

@class TVCard;

@interface TVTag : TVBase

@property (nonatomic, retain) NSDate * createdAt;
@property (nonatomic, retain) NSString * createdBy;
@property (nonatomic, retain) NSString * tagName;
@property (nonatomic, retain) NSSet *hasCard;
@end

@interface TVTag (CoreDataGeneratedAccessors)

- (void)addHasCardObject:(TVCard *)value;
- (void)removeHasCardObject:(TVCard *)value;
- (void)addHasCard:(NSSet *)values;
- (void)removeHasCard:(NSSet *)values;

@end
