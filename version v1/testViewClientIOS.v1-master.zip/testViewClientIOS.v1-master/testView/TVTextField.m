//
//  TVTextField.m
//  testView
//
//  Created by Liwei on 11/10/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTextField.h"

@implementation TVTextField

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
