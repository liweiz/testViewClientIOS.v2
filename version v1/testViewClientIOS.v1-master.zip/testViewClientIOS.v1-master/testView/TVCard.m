//
//  TVCard.m
//  testView
//
//  Created by Liwei on 10/29/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVCard.h"
#import "TVTag.h"
#import "TVUser.h"


@implementation TVCard

@dynamic collectedAt;
@dynamic context;
@dynamic createdAt;
@dynamic createdBy;
@dynamic detail;
@dynamic sourceLang;
@dynamic target;
@dynamic targetLang;
@dynamic translation;
@dynamic hasTag;
@dynamic collectedBy;

@end
