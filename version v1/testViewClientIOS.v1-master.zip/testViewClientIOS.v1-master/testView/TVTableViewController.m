//
//  TVTableViewController.m
//  testView
//
//  Created by Liwei on 2013-08-09.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTableViewController.h"
#import "TVTableViewCell.h"
#import "TVView.h"
#import "TVCard.h"
#import "TVUser.h"
#import "TVNonCardsBaseViewController.h"
#import "UIViewController+sharedMethods.h"

@interface TVTableViewController ()

@end

@implementation TVTableViewController

@synthesize managedObjectContext;
@synthesize managedObjectModel;
@synthesize persistentStoreCoordinator;
@synthesize fetchedResultsController, fetchRequest, changeIsUserDriven, tempSize, myEntityName, cellTitle, cellDetail, positionY, arrayDataSource, tempAddedRows, startWithEditMode, targetTableDataSource, dataSourceIsForTargetTable, relationshipKey, arrayDataSourceFullySelected, arrayDataSourcePartlySelected,arrayDataSourceUnselected, num, changeMadeSet, selectionSetOrigin, targetTableViewNeedReset;
@synthesize pathOfRowReadyToDelete, deleteViewIn, deleteViewOut, pathOfTagAll, byCellTitleAlphabetA, byCreatorA, byTimeCollectedA, byTimeCreatedA, byCellTitleAlphabetD, byCreatorD, byTimeCollectedD, byTimeCreatedD,tempAddedRowsIsOn, objectsForInsertion, fullySelectedRowsNow, partlySelectedRowsNow, objectsForInsertionThisTime, tagsSelected, sortDescriptors, cardSortDescriptorsAlphabetAFirst, cardSortDescriptorsTimeCollectedDFirst, user, sortOptions;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)loadView
{
    // Config tableView
    CGRect firstRect = [[UIScreen mainScreen] applicationFrame];
    self.tempSize = firstRect.size;
    // Notice the extraHeightReduce for height adjustment
    CGRect tempRect = CGRectMake(0.0, self.positionY, self.tempSize.width, self.tempSize.height - self.extraHeightReduce);
    
    self.tableView = [[UITableView alloc] initWithFrame:tempRect style:UITableViewStylePlain];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.allowsMultipleSelection = NO;
    self.tableView.allowsSelectionDuringEditing = YES;
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.changeIsUserDriven = NO;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    // This will refresh data manually and both cardsTable and tagTable will be refreshed
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(refreshTableWithNoOptionalArray) forControlEvents:UIControlEventValueChanged];
    
    // Config fetch request
    self.fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:self.myEntityName inManagedObjectContext:self.managedObjectContext];
    self.fetchRequest.Entity = entity;
    
    // Config sort setting
    self.byCreatorA = [NSSortDescriptor sortDescriptorWithKey:@"createdBy" ascending:YES comparator:^(NSString *obj1, NSString *obj2) {
        return [obj1 localizedCompare:obj2];
    }];
    self.byTimeCollectedD = [[NSSortDescriptor alloc] initWithKey:@"collectedAt" ascending:NO];
    self.byCellTitleAlphabetA = [NSSortDescriptor sortDescriptorWithKey:self.cellTitle ascending:YES comparator:^(NSString *obj1, NSString *obj2) {
        return [obj1 localizedCompare:obj2];
    }];
    self.byTimeCreatedD = [[NSSortDescriptor alloc] initWithKey:@"createdAt" ascending:NO];
    self.byCreatorD = [NSSortDescriptor sortDescriptorWithKey:@"createdBy" ascending:NO comparator:^(NSString *obj1, NSString *obj2) {
        return [obj1 localizedCompare:obj2];
    }];
    self.byTimeCollectedA = [[NSSortDescriptor alloc] initWithKey:@"collectedAt" ascending:YES];
    self.byCellTitleAlphabetD = [NSSortDescriptor sortDescriptorWithKey:self.cellTitle ascending:NO comparator:^(NSString *obj1, NSString *obj2) {
        return [obj1 localizedCompare:obj2];
    }];
    self.byTimeCreatedA = [[NSSortDescriptor alloc] initWithKey:@"createdAt" ascending:YES];
    self.sortOptions = [NSMutableDictionary dictionaryWithCapacity:1];
    [self.sortOptions setValue:@[byTimeCollectedA, byCellTitleAlphabetA] forKey:@"collectedAtAAlphabetA"];
    [self.sortOptions setValue:@[byTimeCollectedD, byCellTitleAlphabetA] forKey:@"collectedAtDAlphabetA"];
    [self.sortOptions setValue:@[byCellTitleAlphabetA, byTimeCollectedD] forKey:@"AlphabetAcollectedAtD"];
    [self.sortOptions setValue:@[byCellTitleAlphabetD, byTimeCollectedD] forKey:@"AlphabetDcollectedAtD"];
    
    self.cardSortDescriptorsTimeCollectedDFirst = @[self.byTimeCollectedD, self.byCellTitleAlphabetA];
    self.cardSortDescriptorsAlphabetAFirst = @[self.byCellTitleAlphabetA, self.byTimeCollectedD];
    NSPredicate *predicate;
    if ([self.myEntityName isEqualToString:@"TVCard"]) {
        self.sortDescriptors = nil;

        self.sortDescriptors = @[self.byTimeCollectedD];
        predicate = [NSPredicate predicateWithFormat:@"not (editAction like 'delete')"];
    }
    if ([self.myEntityName isEqualToString:@"TVTag"]) {
        if (self.startWithEditMode == YES) {
            // Do not show "All" tag here, since user could not delete/edit/select it in multiSelection mode. Use predicate on createdBy to filter.
            predicate = [NSPredicate predicateWithFormat:@"createdBy like 'user'"];
        } else {
            predicate = [NSPredicate predicateWithFormat:@"(createdBy like 'user') || (createdBy like 'systemDefault')"];
        }
        self.sortDescriptors = nil;
        self.sortDescriptors = @[self.byTimeCreatedD];
    }
    
    self.fetchRequest.sortDescriptors = self.sortDescriptors;
    if (predicate) {
        self.fetchRequest.predicate = predicate;
    }
    // Config fetchResultController
    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:self.fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:nil];
    self.fetchedResultsController.delegate = self;
    
    // Populate table with data
    [self refreshTableWithOptionalArray:self.targetTableDataSource];
    
    if ([self.tagsSelected count] > 0) {
        // Configure according to the latest self.tagsSelected
        [self preselectFromSet:self.tagsSelected inTableViewController:self];
    }
}

- (void)refreshTableWithNoOptionalArray
{
    [self refreshTableWithOptionalArray:nil];
}

- (void)refreshTableWithOptionalArray:(NSArray *)optionalArray
{
    [self refreshDataWithOptionalArray:optionalArray];
    // This will be changed, since communication with back-end will take time
    // Before testing with back-end, keep it this way for standalone app test
    [self.refreshControl endRefreshing];
    [self.tableView reloadData];
    if (self.startWithEditMode == YES) {
        [self.tableView setEditing:YES animated:NO];
    }
}

- (void)refreshDataWithOptionalArray:(NSArray *)optionalArray
{
    NSError __autoreleasing *error = nil;
    [self.fetchedResultsController performFetch:&error];
    
    if (self.fetchedResultsController.fetchedObjects == nil) {
        // Handle the error.
//        UIAlertView *emptyDataNotice = [[UIAlertView alloc] initWithTitle:@"No record found" message:@"Add new one or retry later" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil];
//        [emptyDataNotice show];
    }
    self.arrayDataSource = nil;
    self.arrayDataSource = [self getLatestArrayDataSourceWithOptionalArray:optionalArray];
    // Only targetTable needs followings:
    if (self.dataSourceIsForTargetTable == YES) {
        // Reset fullySelectedRows and partlySelectedRows everytime the dataSource is reloaded.
        // Both fullySelected and partlySelected mean a cell is selected, so it's definitely in selectedRows.
        self.fullySelectedRowsNow = nil;
        self.fullySelectedRowsNow = [NSMutableSet setWithCapacity:1];
        [self.fullySelectedRowsNow unionSet:self.arrayDataSourceFullySelected];
        self.partlySelectedRowsNow = nil;
        self.partlySelectedRowsNow = [NSMutableSet setWithCapacity:1];
        [self.partlySelectedRowsNow unionSet:self.arrayDataSourcePartlySelected];
    }
}

- (NSIndexPath *)convertControllerResultsObject:(NSManagedObject *)object toNewArray:(NSArray *)array
{
    // Before this step, it might be necessary to refresh the arrayDataSource
    return [NSIndexPath indexPathForRow:[array indexOfObject:object] inSection:0];
}

- (NSMutableArray *)getLatestArrayDataSourceWithOptionalArray:(NSArray *)optionalArray
{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:1];
    // Only targetTableView will have this and only tagTableView provides the option to add new tags. So the property name is tempAddedRows
    if ([self.tempAddedRows count] > 0) {
        [array addObjectsFromArray:self.tempAddedRows];
    }
    self.sortDescriptors = nil;
    if ([self.myEntityName isEqualToString:@"TVCard"]) {
        // Append the array to the tempAddedArray to make new ones on top and the existing ones sorted alphabetly.
        self.sortDescriptors = [self.sortOptions valueForKey:user.sortOption];
    }
    if ([self.myEntityName isEqualToString:@"TVTag"]) {
        self.sortDescriptors = @[self.byCreatorA, self.byCellTitleAlphabetA];
    }
    NSArray *arrayAfterSorting = [self.fetchedResultsController.fetchedObjects sortedArrayUsingDescriptors:self.sortDescriptors];
    
    if (self.dataSourceIsForTargetTable == YES) {
        //self.rowContentKey must be configured right after the initiation of the tableViewController
        [array addObjectsFromArray:optionalArray];
    } else {
        [array addObjectsFromArray:arrayAfterSorting];
    }
    return array;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    // This part is not effected by wether dataSouce is array
    return [self.fetchedResultsController.sections count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [self.arrayDataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    [self.tableView registerClass:[TVTableViewCell class] forCellReuseIdentifier:@"Cell"];
    TVTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    NSManagedObject *managedObject;
    managedObject = [self.arrayDataSource objectAtIndex:indexPath.row];
    
    [self configureCell:cell cellForRowAtIndexPath:indexPath];
    cell.cellLabel.text = [managedObject valueForKey:self.cellTitle];
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.myEntityName isEqualToString:@"TVTag"]) {
        TVTableViewController *controller = (TVTableViewController *)tableView.dataSource;
        if ([[[controller.arrayDataSource objectAtIndex:indexPath.row] valueForKey:self.cellTitle] isEqualToString:@"All"]) {
            // Disable the interaction of "All" in editing mode
            
            return NO;
        } else {
            return YES;
        }
    } else {
        return YES;
    }
}

- (void)configureCell:(TVTableViewCell *)cell cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // tableViewCell has three statuses: 0: unselected, 1: fully selected, 2: partly selected
    
    // Configure statusCode if needed
    [self configureStatusCodeForCell:cell atIndexPath:indexPath];
    NSLog(@"cell.statusCode: %i", cell.statusCode);
    // Mark the origin statusCode for change observation.
    cell.statusCodeOrigin = cell.statusCode;
    // Get subviews ready to attach related tapGesture
    [cell layoutIfNeeded];
    [cell.selectionTap addTarget:self action:@selector(triggerSelection:)];
    [cell.selectionTapMini addTarget:self action:@selector(triggerSelection:)];
    [cell.selectionLongPressTap addTarget:self action:@selector(triggerEdit:)];
    [cell.selectionLongPressTapMini addTarget:self action:@selector(triggerEdit:)];
    [cell.deleteTap addTarget:self action:@selector(deleteRow:)];
    cell.baseScrollView.delegate = self;
    [cell updateEditView];
    
   
}

- (void)configureStatusCodeForCell:(TVTableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath
{
    if (self.dataSourceIsForTargetTable == YES) {
        // This means in the tableView is targetTableView and in multiselection mode. Three statuses are on. Enable the tapSelection of cell and start with the information from relationship counts. Each cell's status code is configured before the cell is in use.
        // Not able to delete while operating in target table
        cell.baseScrollView.scrollEnabled = NO;
        NSManagedObject *tempManagedObject = [self.arrayDataSource objectAtIndex:indexPath.row];
        // Two possibilities here
        if ([self.partlySelectedRowsNow containsObject:tempManagedObject]) {
            // For partly selected ones, all three statuses are open
            cell.partlySelectedIsOn = YES;
            cell.statusCode = 2;
        }
        else if ([self.fullySelectedRowsNow containsObject:tempManagedObject]) {
            // For fully selected ones, only two statuses are open
            cell.partlySelectedIsOn = NO;
            cell.statusCode = 1;
        }
        else {
            // For unselected ones, only two statuses are open
            cell.partlySelectedIsOn = NO;
            cell.statusCode = 0;
        }
    } else {
        // Two statuses are on. Disable the tapSelection of cell and use the default cell selectoin management. Start with no selection in both normal and edit mode. No need to configure the statusCode since selection management is through system default.
        cell.partlySelectedIsOn = NO;
        if (self.tableView.editing == YES) {
            if ([self.tableView.indexPathsForSelectedRows containsObject:indexPath]) {
                cell.statusCode = 1;
            } else {
                cell.statusCode = 0;
            }
        } else {
            if ([self.tableView.indexPathsForSelectedRows count] > 0 && self.tableView.indexPathForSelectedRow.row == indexPath.row) {
                // Configure cell
                cell.statusCode = 1;
            } else {
                cell.statusCode = 0;
            }
        }
    }
}

// Edit cellTitle after longPressing
- (void)triggerEdit:(UILongPressGestureRecognizer *)sender
{
    if (sender.state == UIGestureRecognizerStateBegan) {
        TVNonCardsBaseViewController *controller = (TVNonCardsBaseViewController *)self.parentViewController;
        TVTableViewCell *cell;
        if ([sender.view.superview.superview isKindOfClass:[UITableViewCell class]]) {
            cell = (TVTableViewCell *)sender.view.superview.superview;
        }
        controller.addTextField.text = cell.textLabel.text;
        [controller.addTextField becomeFirstResponder];
        TVView *view = (TVView *)[UIApplication sharedApplication].keyWindow.rootViewController.view;
        view.touchToDismissKeyboardIsOff = YES;
    }
    if (sender.state == UIGestureRecognizerStateEnded || sender.state == UIGestureRecognizerStateCancelled) {
        TVView *view = (TVView *)[UIApplication sharedApplication].keyWindow.rootViewController.view;
        view.touchToDismissKeyboardIsOff = NO;
    }
}

// Actions after tapping on a cell
- (void)triggerSelection:(UITapGestureRecognizer *)sender
{
    UITapGestureRecognizer *tempSender = sender;
    // Two tapGestureRecognizers have different views attached, so the cell is at different levels.
    // For selectionTap
    if ([tempSender.view.superview.superview isKindOfClass:[UITableViewCell class]]) {
        NSIndexPath *path = [self.tableView indexPathForCell:(UITableViewCell *)tempSender.view.superview.superview];
        if (self.tableView.editing == YES && [self.myEntityName isEqualToString:@"TVTag"] && path && path.row == 0 && [[[self.arrayDataSource objectAtIndex:0] valueForKey:self.cellTitle] isEqualToString:@"All"]) {
            // Do not select
        } else {
            [self selectionActionAtPath:path];
        }
    } else {
        // Handle error
    }
    // For selectionTapMini
    if ([tempSender.view.superview.superview.superview isKindOfClass:[UITableViewCell class]]) {
        NSIndexPath *path = [self.tableView indexPathForCell:(UITableViewCell *)tempSender.view.superview.superview.superview];
        if (self.tableView.editing == YES && [self.myEntityName isEqualToString:@"TVTag"] && path && path.row == 0 && [[[self.arrayDataSource objectAtIndex:0] valueForKey:self.cellTitle] isEqualToString:@"All"]) {
            // Do not select
        } else {
            [self selectionActionAtPath:path];
        }
    } else {
        // Handle error
    }
}

- (void)selectionActionAtPath:(NSIndexPath *)path
{
    // Use statusCode to identify and switch among statuses on cell level.
    // Use fully/partly selectedRowsNow to identify and take action on tableView level.
    NSManagedObject *obj = [self.arrayDataSource objectAtIndex:path.row];
    NSLog(@"selectionAction Path: %i", path.row);
    if (self.dataSourceIsForTargetTable == YES) {
        // fullySelected and unSelected at the begining only have to switch between two statuses
        if ([self.arrayDataSourcePartlySelected containsObject:obj]) {
            if ([self.fullySelectedRowsNow containsObject:obj]) {
                [self.fullySelectedRowsNow removeObject:obj];
                [self.tableView deselectRowAtIndexPath:path animated:YES];
                [self.tableView.delegate tableView:self.tableView didDeselectRowAtIndexPath:path];
            }
            else if ([self.partlySelectedRowsNow containsObject:obj]) {
                [self.partlySelectedRowsNow removeObject:obj];
                [self.fullySelectedRowsNow addObject:obj];
//                [self.tableView selectRowAtIndexPath:path animated:YES scrollPosition:UITableViewScrollPositionNone];
//                [self.tableView.delegate tableView:self.tableView didSelectRowAtIndexPath:path];
            } else {
                [self.partlySelectedRowsNow addObject:obj];
                [self.tableView selectRowAtIndexPath:path animated:YES scrollPosition:UITableViewScrollPositionNone];
                [self.tableView.delegate tableView:self.tableView didSelectRowAtIndexPath:path];
            }
        } else {
            if ([self.fullySelectedRowsNow containsObject:obj]) {
                [self.fullySelectedRowsNow removeObject:obj];
                [self.tableView deselectRowAtIndexPath:path animated:YES];
                [self.tableView.delegate tableView:self.tableView didDeselectRowAtIndexPath:path];
            } else {
                [self.fullySelectedRowsNow addObject:obj];
                [self.tableView selectRowAtIndexPath:path animated:YES scrollPosition:UITableViewScrollPositionNone];
                [self.tableView.delegate tableView:self.tableView didSelectRowAtIndexPath:path];
            }
        }
    } else {
        
        BOOL alreadySelected = NO;
        if ([self.tableView.indexPathsForSelectedRows containsObject:path]) {
            // Already selected, deselect this one
            alreadySelected = YES;
            [self.tableView deselectRowAtIndexPath:path animated:YES];
            [self.tableView.delegate tableView:self.tableView didDeselectRowAtIndexPath:path];
        }
        if (alreadySelected == NO) {
            [self.tableView selectRowAtIndexPath:path animated:YES scrollPosition:UITableViewScrollPositionNone];
            [self.tableView.delegate tableView:self.tableView didSelectRowAtIndexPath:path];
        }
    }
    NSLog(@"Current row selection number: %i", [[self.tableView indexPathsForSelectedRows] count]);
}

- (void)deleteRow:(id)sender
{
    UITapGestureRecognizer *tempSender = sender;
    if ([tempSender.view.superview.superview.superview.superview isKindOfClass:[UITableViewCell class]]) {
        NSIndexPath *path = [self.tableView indexPathForCell:(UITableViewCell *)tempSender.view.superview.superview.superview.superview];
        TVBase *objToDelete = [self.arrayDataSource objectAtIndex:path.row];
        [self deleteRecord:objToDelete];
        [self proceedChangesInContext:self.managedObjectContext willSendRequest:YES];
    } else {
        // Handle error
    }
}

#pragma mark - deleteView show/hide management
// Call this method when uncover a new row's deleteView
- (void)deleteViewWillShownAtIndexPath:(NSIndexPath *)path deleteView:(UIView *)view
{
    self.deleteViewOut = self.deleteViewIn;
    self.deleteViewIn = nil;
    self.pathOfRowReadyToDelete = nil;
    self.pathOfRowReadyToDelete = path;
    self.deleteViewIn = view;
    // deleteViewIn isEqual:self.deleteViewOut at this moment means no new deleteView is touched. Follow user's gesture
    if (![self.deleteViewIn isEqual:self.deleteViewOut]) {
        [(UIScrollView *)[self.deleteViewOut superview] setContentOffset:CGPointZero animated:YES];
    }
    self.deleteViewOut = nil;
}

// Call this method when a uncovered deleteView is closing manually
- (void)deleteViewWillHide
{
    self.pathOfRowReadyToDelete = nil;
    self.deleteViewIn = nil;
}

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    if ([scrollView.superview.superview.superview isKindOfClass:[UITableViewCell class]]) {
        // Change deleteView's width accordingly. Now use scrollView's height as deleteView's width.
        if (targetContentOffset->x >= scrollView.frame.size.height / 2) {
            targetContentOffset->x = scrollView.frame.size.height;
        }
        else if (targetContentOffset->x < scrollView.frame.size.height / 2) {
            targetContentOffset->x = 0.0;
        }
        if (targetContentOffset->x == 0.0) {
            // Moving to hide deleteView
            if ([scrollView isEqual:self.deleteViewIn.superview]) {
                [self deleteViewWillHide];
            }
        }
        else if (targetContentOffset->x == scrollView.frame.size.height) {
            // Moving to show deleteView
            NSIndexPath *path = [self.tableView indexPathForCell:(UITableViewCell *)scrollView.superview.superview.superview];
            TVTableViewCell *cell = (TVTableViewCell *)scrollView.superview.superview.superview;
            [self deleteViewWillShownAtIndexPath:path deleteView:cell.deleteView];
        }
    }
}

// Hide deleteView programmatically
- (void)hideDeleteViewIn
{
    if (self.deleteViewIn) {
        UIScrollView *view = (UIScrollView *)self.deleteViewIn.superview;
        [view setContentOffset:CGPointZero animated:YES];
        self.deleteViewIn = nil;
    }
}

#pragma mark - selection-made change observation when self.dataSourceIsArray is YES for originTableView
// Any selection change in originTableView before entering the targetTableView layer will lead to reset of the selection in targetTableView since it means operation on a different set of objs. This is executed after the user swich the two layers back and forth.
// Record the indexPath to compare
- (void)resetTargetTableViewOrNOT
{
    if (!self.selectionSetOrigin) {
        // Probably the first time of executing, recording is all we need to do in this case.
        self.selectionSetOrigin = [NSMutableSet setWithCapacity:1];
        [self.selectionSetOrigin addObjectsFromArray:[self.tableView indexPathsForSelectedRows]];
        self.targetTableViewNeedReset = YES;
    } else {
        NSMutableSet *currentSet = [NSMutableSet setWithCapacity:1];
        [currentSet addObjectsFromArray:[self.tableView indexPathsForSelectedRows]];
        if (![currentSet isEqualToSet:self.selectionSetOrigin]) {
            // Reset the targetTableView
            self.targetTableViewNeedReset = YES;
            // Update selectionSetOrigin
            [self.selectionSetOrigin setSet:currentSet];
        } else {
            // No need to reset the targetTableView and keep the selectionSetOrigin
            self.targetTableViewNeedReset = NO;
        }
    }
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    NSLog(@"Selected555555Path: %i", indexPath.row);
//    NSLog(@"tableView.indexPathsForSelectedRows count55555555: %i", [tableView.indexPathsForSelectedRows count]);
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}



#pragma mark - selection-made change observation when self.dataSourceIsArray is YES for targetTableView

// Each tapGesture adds a related managedObject and its corresponding cell.statusCodeOrigin to a waitingListSet, if it is not already in that set. When user leaves the targetTableView layer, find out the final statusCodes for those managedObject's cells and compare them. Generate a changeSet deriving from the waitingListSet.
- (void)addToWaitingList:(TVTableViewCell *)cell
{
    if (!self.waitingList) {
        self.waitingList = [NSMutableSet setWithCapacity:self.num];
    }
    /*
     Create an array to store necessary info.
     position 0: NSManagedObject
     position 1: cell.statusCodeOrigin
     position 2: NSIndexPath
     position 3 and beyond: the statusCode each tap brings and the last  obj of the array is currentStatusCode, if any tapAction occurs.
     */
    NSIndexPath *tempPath = [self.tableView indexPathForCell:cell];
    NSManagedObject *obj = [arrayDataSource objectAtIndex:tempPath.row];
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:3];
    NSArray *componentArray = [NSArray arrayWithObjects:obj, [NSNumber numberWithInteger:cell.statusCodeOrigin], tempPath, nil];
    [tempArray addObjectsFromArray:componentArray];
    [self.waitingList addObject:tempArray];
}

- (void)recordCurrentStatusCodeToWaitingList:(TVTableViewCell *)cell
{
    NSIndexPath *searchPath = [self.tableView indexPathForCell:cell];
    for (NSMutableArray *obj in self.waitingList) {
        // Get the array
        NSMutableArray *array = [obj objectAtIndex:searchPath.row];
        // Find the corresponding obj by matching indexPath
        if ([array objectAtIndex:2] == searchPath) {
            [array addObject:[NSNumber numberWithInteger:cell.statusCode]];
            break;
        }
    }
}

- (NSMutableSet *)getChangeSet
{
    // Match the current statusCode with statusCodeOrigin in waitingList
    if (!self.changeMadeSet) {
        self.changeMadeSet = [NSMutableSet setWithCapacity:1];
    } else {
        [self.changeMadeSet removeAllObjects];
    }
    for (NSMutableArray *obj in self.waitingList) {
        if ([obj count] > 3 && [[obj lastObject] integerValue] != [[obj objectAtIndex:1] integerValue]) {
            [self.changeMadeSet addObject:obj];
        }
    }
    return self.changeMadeSet;
}

#pragma mark - fetchedResultsController delegate callbacks

- (void)controllerWillChangeContent:(NSFetchedResultsController *)controller {
    // Refresh the arrayDataSource to form a new array for insertion while keep the old one for reloading and deletion
    self.objectsForInsertion = nil;
    [self.tableView beginUpdates];
}

//- (void)controller:(NSFetchedResultsController *)controller didChangeSection:(id <NSFetchedResultsSectionInfo>)sectionInfo
//           atIndex:(NSUInteger)sectionIndex forChangeType:(NSFetchedResultsChangeType)type {
//     switch(type) {
//     case NSFetchedResultsChangeInsert:
//     [self.tableView insertSections:[NSIndexSet indexSetWithIndex:sectionIndex]
//     withRowAnimation:UITableViewRowAnimationFade];
//     break;
//     
//     case NSFetchedResultsChangeDelete:
//     [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:sectionIndex]
//     withRowAnimation:UITableViewRowAnimationFade];
//     break;
//     }
//}

// A custom helper method that takes an existing cell and updates it in place
//- (void)configureCell:(UITableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject
       atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type
      newIndexPath:(NSIndexPath *)newIndexPath {
    
    if (!self.changeIsUserDriven) {
        
        UITableView *tableView = self.tableView;
        NSIndexPath *pathNeeded;
        if (indexPath) {
            pathNeeded = [self convertControllerResultsObject:anObject toNewArray:self.arrayDataSource];
        }
        switch(type) {
                
            case NSFetchedResultsChangeInsert:
                // Insertion needs to find the indexPath in the new dataSource
                if (!self.objectsForInsertion) {
                    self.objectsForInsertion = [NSMutableSet setWithCapacity:1];
                }
                [self.objectsForInsertion addObject:anObject];
                if (!self.objectsForInsertionThisTime) {
                    self.objectsForInsertionThisTime = [NSMutableSet setWithCapacity:1];
                }
                [self.objectsForInsertionThisTime addObject:anObject];
                break;
                
            case NSFetchedResultsChangeDelete:
                // Removing and updating use the indexPath for existing dataSource
                // Updating and insertion do not happen at the same loop in this app. So no need to update the dataSource here.
                [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:pathNeeded]
                                 withRowAnimation:UITableViewRowAnimationFade];
                break;
                
            case NSFetchedResultsChangeUpdate:
                // this is from http://oleb.net/blog/2013/02/nsfetchedresultscontroller-documentation-bug/
                [tableView reloadRowsAtIndexPaths:@[pathNeeded] withRowAnimation:UITableViewRowAnimationAutomatic];
                //[self configureCell:[tableView cellForRowAtIndexPath:indexPath]
                //atIndexPath:indexPath];
                break;
                
            case NSFetchedResultsChangeMove:
//                [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath]
//                                 withRowAnimation:UITableViewRowAnimationFade];
//                [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newIndexPath]
//                                 withRowAnimation:UITableViewRowAnimationFade];
                break;
        }
    }
}

- (void)controllerDidChangeContent:(NSFetchedResultsController *)controller
{
    // Configure new indexPath for instersion use
    NSArray *arrayForInsertion = [self getLatestArrayDataSourceWithOptionalArray:self.targetTableDataSource];
    if ([self.objectsForInsertion count] > 0) {
        for (NSManagedObject *obj in self.objectsForInsertion) {
            NSIndexPath *newPathNeeded = [self convertControllerResultsObject:obj toNewArray:arrayForInsertion];
            [self.tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:newPathNeeded] withRowAnimation:UITableViewRowAnimationFade];
        }
    }
    [self refreshDataWithOptionalArray:self.targetTableDataSource];
    [self.tableView endUpdates];
}



@end
