//
//  TVNonCardsBaseViewController.h
//  testView
//
//  Created by Liwei on 2013-09-03.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TVTableViewController.h"
#import "TVUser.h"

@interface TVNonCardsBaseViewController : UIViewController <UITextFieldDelegate, UIScrollViewDelegate>

@property (strong, nonatomic) TVTableViewController *myTableViewController;

@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (assign, nonatomic) CGSize tempSize;
@property (assign, nonatomic) CGFloat positionY;
@property (assign, nonatomic) BOOL addContactAndSendingTag;

@property (strong, nonatomic) UITextField *addTextField;
@property (strong, nonatomic) UIView *actionButton;
@property (strong, nonatomic) UIScrollView *keyboardSlot;
@property (strong, nonatomic) UITapGestureRecognizer *actionButtonTap;

@property (strong, nonatomic) UIPinchGestureRecognizer *pinchToExitGesture;

// This must be configured right after the controller instance is available and before loadView
@property (assign, nonatomic) BOOL tempAddedRowsIsOn;
@property (assign, nonatomic) BOOL startWithEditMode;

// Current tag selection
@property (strong, nonatomic) NSMutableSet *tagsSelected;

@property (strong, nonatomic) TVUser *user;

@end
