//
//  TVTagsMultiTabViewController.m
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTagsMultiTabViewController.h"

@interface TVTagsMultiTabViewController ()

@end

@implementation TVTagsMultiTabViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.positionY = 44.0;
        self.extraHeightReduce = 44.0;
        self.myEntityName = @"TVTag";
        self.cellTitle = @"tagName";
        self.tempAddedRowsIsOn = NO;
        self.startWithEditMode = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    if (self.tableView.contentInset.bottom == 0.0) {
        self.tableView.contentInset = UIEdgeInsetsMake(0.0, 0.0, 44.0f, 0.0);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
