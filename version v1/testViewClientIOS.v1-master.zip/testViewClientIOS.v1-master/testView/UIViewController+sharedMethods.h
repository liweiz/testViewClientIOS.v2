//
//  UIViewController+sharedMethods.h
//  testView
//
//  Created by Liwei on 2013-08-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TVTableViewController.h"
#import "TVNewBaseViewController.h"
#import "TVNonCardsBaseViewController.h"
#import "TVBase.h"
#import "TVCard.h"
#import "TVTag.h"
#import "TVUser.h"
#import "TVTableViewCell.h"
#import "TVAppRootViewController.h"
#import "KeychainItemWrapper.h"

typedef NS_ENUM(NSInteger, ConnectionErrorStatus) {
    ServerNotAvailable,
    AccountAlreadyExists,
    IncorrectAccountNameOrPassword,
    DataDownloaded,
    NoDataDownloaded,
    TimeOut,
    NoSuchAccountExists,
    OtherError
};

@interface UIViewController (sharedMethods)

#pragma mark - present another view back and forth

- (void)showNewView:(UIView *)newView newViewController:(UIViewController *)newController currentView:(UIView *)currentView baseView:(UIView *)base tapGesture:(UITapGestureRecognizer *)tapGesture longPressGesture:(UILongPressGestureRecognizer *)longPressGesture;
- (void)hideNewView:(UIView *)newView currentView:(UIView *)currentView baseView:(UIView *)base tapGesture:(UITapGestureRecognizer *)tapGesture pinchGesture:(UIPinchGestureRecognizer *)pinchGesture;
- (void)comeThrough:(UIView *)view anchorPoint:(CGPoint)point;
- (void)comeUp:(UIView *)view anchorPoint:(CGPoint)point;
- (void)goThrough:(UIView *)view anchorPoint:(CGPoint)point;
- (void)goDown:(UIView *)view anchorPoint:(CGPoint)point;

#pragma mark - remove blank spaces at the beginning and end of any input

- (NSString *)trimInput:(NSString *)text;

#pragma mark - pre-selection action

- (void)preselectFromSet:(NSSet *)set inTableViewController:(TVTableViewController *)tableViewController;

#pragma mark - targetTable multiselection dataSource based on pre-selection

- (NSArray *)getDataSourceReadyFromDataSource:(NSArray *)array withPreselectedSet:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor;
- (NSArray *)getPreselectedArray:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor;
- (NSArray *)getUnselectedArrayFromDataSource:(NSArray *)array withPreselectedSet:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor;

#pragma mark - targetTable multiselection dataSource from originTableView

- (NSArray *)getTargetTableDataSourceArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor targetFetchedResultsController:(NSFetchedResultsController *)newFetchedResultsController;
- (NSArray *)getTargetTableDataSourceUnselectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor targetFetchedResultsController:(NSFetchedResultsController *)newFetchedResultsController;
- (NSArray *)getTargetTableDataSourceFullySelectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor;
- (NSArray *)getTargetTableDataSourcePartlySelectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor;

- (NSMutableSet *)getPartlySelectedSetFromOriginalTable:(UITableView *)table fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key;
- (NSMutableSet *)getFullySelectedSetFromOriginalTable:(UITableView *)table fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key;
- (NSInteger)uniqueCount:(NSManagedObject *)managedObject byRelationshipKey:(NSString *)key;
- (NSMutableSet *)getTargetTableDataSourceSelectedSetForEditMode:(UITableView *)originTableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key;
- (NSMutableSet *)getOriginalManagedObjects:(UITableView *)originTableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController;

#pragma mark - multiselection and save

- (void)changeSet:(NSSet *)changeSet relationshipKey:(NSString *)key selectionSetOrigin:(NSSet *)originSet;
- (void)saveMultiselectionChange:(NSManagedObjectContext *)managedObjectContext;

#pragma mark - horizontal scrolling freeze/defreeze

- (void)freezeRootView;
- (void)defreezeRootView;

#pragma mark - sync action utilities

- (TVAppRootViewController *)getAppRootViewController;
- (NSString *)convertNSDate:(NSDate *)date;
- (NSDate *)convertISO8601String:(NSString *)string;
- (NSDictionary *)convertNSManagedObjToDict:(TVBase *)record withEntityDescription:(NSEntityDescription *)description;
- (TVBase *)convertDict:(NSDictionary *)recordDict toNSManagedObj:(TVBase *)record;
- (void)handleConnectionError:(ConnectionErrorStatus)errorStatus;
- (void)showAlertForMessage:(NSString *)message title:(NSString *)title;

#pragma mark - sync action response

- (BOOL)statusCheckForResponse:(NSHTTPURLResponse *)response;
- (BOOL)handleLoginResponse:(NSHTTPURLResponse *)response withData:(NSData *)data;
- (BOOL)savePassToKeychainFromResponse:(NSHTTPURLResponse *)response withData:(NSData *)data;
- (NSString *)getPassFromKeychainEmail:(NSString *)email;
- (void)handleDataSyncResponse:(NSHTTPURLResponse *)response withData:(NSData *)data user:(TVUser *)user withNewCardController:(TVNewBaseViewController *)controller;
- (NSDictionary *)getDictFromResponse:(NSHTTPURLResponse *)response withData:(NSData *)data;
- (void)processEntity:(NSString *)entityName inContext:(NSManagedObjectContext *)context withNewCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user rootResponse:(NSDictionary *)rootResponse;
- (NSArray *)getLocalRecordsForEntityName:(NSString *)entityName user:(TVUser *)user;
- (TVBase *)getRecordForServerID:(NSNumber *)ID WithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context;
- (NSDictionary *)categorizeCreateUpdateDeleteInRecords:(NSArray *)records user:(TVUser *)user inLocalEntity:(NSArray *)localRecords;

#pragma mark - sync action request

- (BOOL)isConnectedToServer;
- (BOOL)startRegistrationLoginWithEmail:(NSString *)email password:(NSString *)password withURLString:(NSString *)URLString;
- (BOOL)startSyncEntitySet:(NSSet *)entities
     withNewCardController:(TVNewBaseViewController *)controller user:(TVUser *)user;
- (BOOL)handleBasicResponse:(NSHTTPURLResponse *)response withJSONData:(NSData *)data error:(NSError *)error;
- (void)makeRequestToCheckActivationStausForUser:(TVUser *)user;
- (void)makeRequestWithEntitySet:(NSSet *)entities
           withNewCardController:(TVNewBaseViewController *)controller
                            user:(TVUser *)user;
- (void)makeRegistrationLoginRequestWithEmail:(NSString *)email password:(NSString *)password withURLString:(NSString *)URLString;
- (NSData *)getUserRegistrationLoginJSONWithEmail:(NSString *)email password:(NSString *)password;
- (NSData *)getJSONForSyncRequestWithEntityNameSet:(NSSet *)entities inContext:(NSManagedObjectContext *)context user:(TVUser *)user;
- (NSDictionary *)getDictionaryForSyncRequestWithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context;
- (NSArray *)getArrayAllForSyncRequestWithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context;
- (NSArray *)getArrayForSyncRequestWithEntityName:(NSString *)name forAction:(NSString *)action inContext:(NSManagedObjectContext *)context convertNSManagedObjToDict:(BOOL)convert;

#pragma mark - record create/update/delete action
- (TVBase *)createRecord:(Class)recordClass recordInResponse:(NSDictionary *)recordInResponse inContext:(NSManagedObjectContext *)context withNewCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user;
- (void)updateRecord:(TVBase *)record recordInResponse:(NSDictionary *)recordInResponse withCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user;
- (void)commitUpdateRecord:(TVBase *)record recordInResponse:(NSDictionary *)recordInResponse;
- (void)deleteRecord:(TVBase *)record;
- (void)commitDeleteRecord:(TVBase *)record;
- (void)proceedChangesInContext:(NSManagedObjectContext *)context willSendRequest:(BOOL)willSendRequest;
- (void)writeToCard:(TVCard *)card recordInResponse:(NSDictionary *)recordDict withController:(TVNewBaseViewController *)controller withUser:(TVUser *)user;
- (void)writeToTag:(TVTag *)tag recordInResponse:(NSDictionary *)recordDict withController:(TVNonCardsBaseViewController *)controller withUser:(TVUser *)user;
- (void)writeToUser:(TVUser *)user recordInResponse:(NSDictionary *)recordDict;

#pragma mark - common create/update/delete action

- (void)createBefore:(TVBase *)base;
- (void)createAfter:(TVBase *)base rootResponse:(NSDictionary *)response;
- (void)updateBefore:(TVBase *)base;
- (void)updateAfter:(TVBase *)base recordInResponse:(NSDictionary *)record;
- (void)deleteBefore:(TVBase *)base;
- (void)deleteAfter:(TVBase *)base;
- (void)actionBefore:(TVBase *)base action:(NSString *)action;
- (void)actionAfter:(TVBase *)base recordInResponse:(NSDictionary *)record;

#pragma mark - Load file from supporting files
- (NSArray *)loadLangArray;

#pragma mark - RequestVersion generator and unique string for device identification

- (void)switchRequestVersionNoUpdate:(TVUser *)user;
- (void)assignRequestVersionNoWithUser:(TVUser *)user allRecord:(NSArray *)allRecord;
- (NSNumber *)generateRequestVersionNo:(NSNumber *)currentRequestVersionNo;
- (NSString *)getUUID;

@end