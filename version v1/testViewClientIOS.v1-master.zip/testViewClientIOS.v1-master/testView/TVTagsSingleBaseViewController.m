//
//  TVTagsSingleBaseViewController.m
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTagsSingleBaseViewController.h"
#import "TVTagsSingleViewController.h"

@interface TVTagsSingleBaseViewController ()

@end

@implementation TVTagsSingleBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.positionY = 44.0f;
    }
    return self;
}



- (void)viewDidLoad
{
    self.myTableViewController = [[TVTagsSingleViewController alloc] init];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.addTextField.frame = CGRectMake(0.0f, 0.0f, self.view.frame.size.width, self.actionButton.frame.size.height);
    self.actionButton.hidden = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
