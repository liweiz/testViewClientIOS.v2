//
//  TVBase.m
//  testView
//
//  Created by Liwei on 12/10/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVBase.h"


@implementation TVBase

@dynamic deletedOnServer;
@dynamic editAction;
@dynamic lastModifiedAtLocal;
@dynamic lastModifiedAtServer;
@dynamic requestVersionNo;
@dynamic serverID;

@end
