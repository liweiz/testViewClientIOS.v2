//
//  TVCardsTopViewController.h
//  testView
//
//  Created by Liwei on 2013-07-25.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVCardsTopViewController : UIViewController

@property (strong, nonatomic) UIView *topView;
@property (assign, nonatomic) CGPoint *position;
@property (assign, nonatomic) CGSize tempSize;

@end
