//
//  TVBase.h
//  testView
//
//  Created by Liwei on 12/10/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface TVBase : NSManagedObject

@property (nonatomic, retain) NSNumber * deletedOnServer;
@property (nonatomic, retain) NSString * editAction;
@property (nonatomic, retain) NSDate * lastModifiedAtLocal;
@property (nonatomic, retain) NSDate * lastModifiedAtServer;
@property (nonatomic, retain) NSNumber * requestVersionNo;
@property (nonatomic, retain) NSNumber * serverID;

@end
