//
//  TVTagsMultiTabViewController.h
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTableViewController.h"

@interface TVTagsMultiTabViewController : TVTableViewController

@end
