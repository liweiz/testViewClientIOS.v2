//
//  TVTag.m
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTag.h"
#import "TVCard.h"


@implementation TVTag

@dynamic createdAt;
@dynamic createdBy;
@dynamic tagName;
@dynamic hasCard;

@end
