//
//  UIViewController+RequestVersionControll.m
//  testView
//
//  Created by Liwei on 12/10/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "UIViewController+RequestVersionControll.h"

@implementation UIViewController (RequestVersionControll)

/*
 The start point of requestVersion is managed by the server. It's a value bound to each device. On server, each UUID is paired with an array that stores all the successfully proccessed requests' requestVersions. Everytime a request received by the server, the server finds if it is in the array. If yes, it has been processed succefully and a http code 200 will be returned. If no, the server will proceed to handle the request and return http code 200 after successfully finishing the job.
 
 User's currentRequestVersion field stands for the current highest requestVersion on client and client uses this as the base to make increment on requestVersion of each request sent.
 Each time a user logs in the system for the first time, the server will sync back the currentRequestVersion to the client as the start point to calculate the requestVerion afterwards.
 
 A request is generated when the editAction is not empty. When a request is generated, the corresponding requestVersion is stored to the record as well. It will not be cleared till the http code 200 in response is received by the client. Or if new edit action happens to the record,  a new requestVersion will be assigned since the old content dose not matter any more. All we need to do is to let the server has the latest change.
 
 A generated request is appended to an incomplete request array. We can also call it a request pool. Those requests with responses 200 are removed as soon as the responses are received.
 */

#pragma mark -

// Get the request pool. Request pool criteria:
// 1. non-blank editAction field
// 2. no serverID assigned, which means a new record created locally
// 3. non-blank requestVersionNo
- (NSArray *)getRequestPoolPartWithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context convertNSManagedObjToDict:(BOOL)convert
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:name];
    NSPredicate *predicateAction = [NSPredicate predicateWithFormat:@"editAction like %@", action];
    [request setPredicate:predicateAction];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastModifiedAtLocal" ascending:YES];
    [request setSortDescriptors:@[sortDescriptor]];
    NSArray *arrayAction = [context executeFetchRequest:request error:nil];
    
    if (convert == YES) {
        NSMutableArray *recordsArray = [NSMutableArray arrayWithCapacity:1];;
        NSEntityDescription *entityDescription = [NSEntityDescription entityForName:name inManagedObjectContext:context];
        for (id obj in arrayAction) {
            NSDictionary *recordDict = [self convertNSManagedObjToDict:obj withEntityDescription:entityDescription];
            [recordsArray addObject:recordDict];
        }
        return recordsArray;
    } else {
        return arrayAction;
    }

}

@end
