//
//  TVTableViewController.h
//  testView
//
//  Created by Liwei on 2013-08-09.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TVTableViewCell.h"
#import "TVUser.h"

@interface TVTableViewController : UITableViewController <NSFetchedResultsControllerDelegate>

@property (assign, nonatomic) BOOL changeIsUserDriven;


@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong, nonatomic) NSFetchRequest *fetchRequest;
@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (assign, nonatomic) BOOL tempAddedRowsIsOn;
@property (assign, nonatomic) CGSize tempSize;
@property (strong, nonatomic) NSMutableArray *tempAddedRows;
@property (strong, nonatomic) NSMutableArray *arrayDataSource;
@property (strong, nonatomic) NSArray *sortDescriptors;
// Fully selected and partly selected both belong to selected
@property (strong, nonatomic) NSMutableSet *arrayDataSourceFullySelected;
@property (strong, nonatomic) NSMutableSet *arrayDataSourcePartlySelected;
@property (strong, nonatomic) NSMutableSet *arrayDataSourceUnselected;
// Need to reset after leaving the tableView
@property (strong, nonatomic) NSMutableSet *fullySelectedRowsNow;
@property (strong, nonatomic) NSMutableSet *partlySelectedRowsNow;
@property (strong, nonatomic) NSMutableSet *waitingList;
@property (strong, nonatomic) NSIndexPath *pathOfTagAll;
@property (strong, nonatomic) NSMutableSet *objectsForInsertion;
@property (strong, nonatomic) NSMutableSet *objectsForInsertionThisTime;
/*
 This is made up of an array that contains:
 position 0: NSManagedObject
 position 1: cell.statusCodeOrigin
 position 2: NSIndexPath
 position 3 and beyond: the statusCode each tap brings and the last  obj of the array is currentStatusCode, if any tapAction occurs.
 */
@property (strong, nonatomic) NSMutableSet *changeMadeSet;
@property (strong, nonatomic) NSMutableSet *selectionSetOrigin;
@property (assign, nonatomic) NSInteger num;
@property (assign, nonatomic) BOOL targetTableViewNeedReset;

// Current tag selection
@property (strong, nonatomic) NSMutableSet *tagsSelected;

// Must be configged before viewDidLoad
@property (assign, nonatomic) CGFloat positionY;

@property (assign, nonatomic) BOOL dataSourceIsForTargetTable;
@property (assign, nonatomic) CGFloat extraHeightReduce;
@property (strong, nonatomic) NSString *myEntityName;
@property (strong, nonatomic) NSString *cellTitle;
@property (strong, nonatomic) NSString *cellDetail;
@property (assign, nonatomic) BOOL startWithEditMode;
@property (strong, nonatomic) NSArray *targetTableDataSource;
@property (strong, nonatomic) NSString *relationshipKey;

@property (assign, nonatomic) NSIndexPath *pathOfRowReadyToDelete;
@property (strong, nonatomic) UIView *deleteViewIn;
@property (strong, nonatomic) UIView *deleteViewOut;

@property (strong, nonatomic) NSSortDescriptor *byCellTitleAlphabetA;
@property (strong, nonatomic) NSSortDescriptor *byTimeCollectedA;
@property (strong, nonatomic) NSSortDescriptor *byTimeCreatedA;
@property (strong, nonatomic) NSSortDescriptor *byCreatorA;
@property (strong, nonatomic) NSSortDescriptor *byCellTitleAlphabetD;
@property (strong, nonatomic) NSSortDescriptor *byTimeCollectedD;
@property (strong, nonatomic) NSSortDescriptor *byTimeCreatedD;
@property (strong, nonatomic) NSSortDescriptor *byCreatorD;
@property (strong, nonatomic) NSMutableDictionary *sortOptions;

@property (strong, nonatomic) NSArray *cardSortDescriptorsAlphabetAFirst;
@property (strong, nonatomic) NSArray *cardSortDescriptorsTimeCollectedDFirst;
@property (strong, nonatomic) TVUser *user;

- (void)refreshTableWithNoOptionalArray;
- (void)refreshTableWithOptionalArray:(NSArray *)optionalArray;
- (void)refreshDataWithOptionalArray:(NSArray *)optionalArray;
- (void)hideDeleteViewIn;
- (void)selectionActionAtPath:(NSIndexPath *)path;
- (void)configureStatusCodeForCell:(TVTableViewCell *)cell atIndexPath:(NSIndexPath *)indexPath;

@end
