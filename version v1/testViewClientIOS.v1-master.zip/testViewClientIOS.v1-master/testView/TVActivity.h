//
//  TVActivity.h
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "TVBase.h"


@interface TVActivity : TVBase

@property (nonatomic, retain) NSString * action;
@property (nonatomic, retain) NSString * descriptionInfo;
@property (nonatomic, retain) NSString * emailAddress;
@property (nonatomic, retain) NSString * tag;
@property (nonatomic, retain) NSDate * timeStamp;

@end
