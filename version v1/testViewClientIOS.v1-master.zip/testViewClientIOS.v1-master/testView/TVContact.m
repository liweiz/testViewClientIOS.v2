//
//  TVContact.m
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVContact.h"


@implementation TVContact

@dynamic emailAddress;
@dynamic timeAdded;
@dynamic userDescription;

@end
