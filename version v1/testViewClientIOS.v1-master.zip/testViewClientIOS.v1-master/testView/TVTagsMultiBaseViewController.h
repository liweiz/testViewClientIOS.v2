//
//  TVTagsMultiBaseViewController.h
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVNonCardsBaseViewController.h"

@interface TVTagsMultiBaseViewController : TVNonCardsBaseViewController

@property (assign, nonatomic) BOOL forTab;

@end
