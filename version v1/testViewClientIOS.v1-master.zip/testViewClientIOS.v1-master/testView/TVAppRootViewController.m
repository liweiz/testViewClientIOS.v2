//
//  TVAppRootViewController.m
//  testView
//
//  Created by Liwei Zhang on 2013-10-18.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVAppRootViewController.h"
#import "UIViewController+sharedMethods.h"



@interface TVAppRootViewController ()

@end

@implementation TVAppRootViewController

@synthesize managedObjectContext, persistentStoreCoordinator, managedObjectModel, userFetchRequest, user, contentViewController, loginViewController, requestReceivedResponse, willSendRequest, passItem;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        static UIColor *backgroundColor = [UIColor colorWithHue:0.62f saturation:0.45f brightness:0.52f alpha:0.8f];
        
    }
    return self;
}

- (void)loadView
{
    CGRect firstRect = [[UIScreen mainScreen] applicationFrame];
    CGRect viewRect = CGRectMake(0.0f, 0.0f, firstRect.size.width, firstRect.size.height);
    self.view = [[UIView alloc] initWithFrame:viewRect];
    self.view.backgroundColor = [UIColor lightGrayColor];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.requestReceivedResponse = YES;
    self.willSendRequest = YES;
    [self loadController];
}

- (void)loadController
{
    
    self.userFetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"TVUser"];
    self.userFetchRequest.predicate = [NSPredicate predicateWithFormat:@"isLoggedIn == YES"];
    NSArray *userArray = [self.managedObjectContext executeFetchRequest:self.userFetchRequest error:nil];
    if (![userArray isEqual: @[]]) {
        self.user = [userArray objectAtIndex:0];
    } else {
        [self loginAsTest];
        NSArray *anotherUserArray = [self.managedObjectContext executeFetchRequest:self.userFetchRequest error:nil];
        self.user = [anotherUserArray objectAtIndex:0];
    }
    
    if (!self.user) {
        // No user is logged in, launch LoginController
        [self loadLoginController];
    } else {
        // User is logged in, launch ContentController
        [self loadContentController];
    }
}

- (void)loginAsTest
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TVUser"];
    request.predicate = [NSPredicate predicateWithFormat:@"isLoggedIn == YES"];
    NSArray *userArray = [self.managedObjectContext executeFetchRequest:request error:nil];
    if ([userArray isEqual: @[]]) {
        //create a test user by faking a response
        NSMutableDictionary *testResponse = [NSMutableDictionary dictionaryWithCapacity:1];
        [testResponse setValue:@"test@test.com" forKey:@"email"];
        NSNumber *isLoggedIn = [NSNumber numberWithBool:YES];
        [testResponse setValue:@"collectedAtDAlphabetA" forKey:@"sortOption"];
        [testResponse setValue:isLoggedIn forKey:@"isLoggedIn"];
        [testResponse setValue:@"Chinese Simplified" forKey:@"sourceLang"];
        [testResponse setValue:@"English" forKey:@"targetLang"];
        [self createRecord:[TVUser class] recordInResponse:testResponse inContext:self.managedObjectContext withNewCardController:nil withNonCardController:nil user:nil];
        [self proceedChangesInContext:self.managedObjectContext willSendRequest:NO];
    }
}

- (void)loadLoginController
{
    self.loginViewController = [[TVLoginViewController alloc] init];
    
    self.loginViewController.managedObjectContext = self.managedObjectContext;
    self.loginViewController.managedObjectModel = self.managedObjectModel;
    self.loginViewController.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    [self addChildViewController:self.loginViewController];
    [self.view addSubview:self.loginViewController.view];
    [self.loginViewController didMoveToParentViewController:self];
}

- (void)loadContentController
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startSync:) name:NSManagedObjectContextDidSaveNotification object:nil];
    self.contentViewController = [[TVContentRootViewController alloc] init];
    
    self.contentViewController.managedObjectContext = self.managedObjectContext;
    self.contentViewController.managedObjectModel = self.managedObjectModel;
    self.contentViewController.persistentStoreCoordinator = self.persistentStoreCoordinator;
    
    self.contentViewController.user = self.user;
    
    [self addChildViewController:self.contentViewController];
    [self.view addSubview:self.contentViewController.view];
    [self.contentViewController didMoveToParentViewController:self];
}

- (void)startSync:(NSNotification *)didSaveNotification
{
    if (self.willSendRequest == YES) {
        NSMutableSet *entitiesToSync = [NSMutableSet setWithCapacity:1];
        [entitiesToSync addObject:@"TVCard"];
        if ([self startSyncEntitySet:entitiesToSync
               withNewCardController:self.contentViewController.myNewBaseViewController user:self.user]) {
            // Successful
            NSLog(@"connected");
        } else {
            // Failed, show indicator to let users know
            NSLog(@"not connected");
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
