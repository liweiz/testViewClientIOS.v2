//
//  TVActivity.m
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVActivity.h"


@implementation TVActivity

@dynamic action;
@dynamic descriptionInfo;
@dynamic emailAddress;
@dynamic tag;
@dynamic timeStamp;

@end
