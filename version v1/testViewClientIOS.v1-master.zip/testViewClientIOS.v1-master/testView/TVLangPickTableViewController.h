//
//  TVLangPickTableViewController.h
//  testView
//
//  Created by Liwei on 10/23/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVLangPickTableViewController : UITableViewController

@property (strong, nonatomic) NSArray *langArray;

@end
