//
//  TVNonCardsBaseViewController.m
//  testView
//
//  Created by Liwei on 2013-09-03.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVNonCardsBaseViewController.h"
#import "TVTag.h"
#import "TVContact.h"
#import "TVActivity.h"
#import "TVView.h"

#import "UIViewController+sharedMethods.h"
#import "TVContentRootViewController.h"

@interface TVNonCardsBaseViewController ()

@end

@implementation TVNonCardsBaseViewController

@synthesize myTableViewController, managedObjectContext, managedObjectModel, persistentStoreCoordinator, tempSize, addContactAndSendingTag, addTextField, actionButton, keyboardSlot, actionButtonTap, pinchToExitGesture, tempAddedRowsIsOn, startWithEditMode, positionY, tagsSelected;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)loadView
{
    CGRect firstRect = [[UIScreen mainScreen] applicationFrame];
    self.tempSize = firstRect.size;
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0.0f, self.positionY, self.tempSize.width, self.tempSize.height)];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    // Add keyboardSlot
    self.keyboardSlot = [[UIScrollView alloc] initWithFrame:CGRectMake(0.0, self.tempSize.height - 44.0, self.tempSize.width, 44.0)];
    // Make the contentSize large enough for different keyboard size, such as English or Chinese. Chinese input has an extra row above the basic keyboard to show the word candidates.
    self.keyboardSlot.contentSize = CGSizeMake(self.tempSize.width, self.tempSize.height * 2);
    self.keyboardSlot.scrollEnabled = NO;
    self.keyboardSlot.delegate = self;
    

    //[self.view addSubview:self.keyboardSlot];
    
    // Add input
    self.addTextField = [[UITextField alloc] initWithFrame:CGRectMake(0.0, 0.0, self.tempSize.width * 3 / 4, 44.0)];
    
    self.addTextField.backgroundColor = [UIColor grayColor];
    self.addTextField.enablesReturnKeyAutomatically = YES;
    self.addTextField.returnKeyType = UIReturnKeyDone;
    self.addTextField.delegate = self;
    [self.keyboardSlot addSubview:self.addTextField];
    
    // Add bottomRight function button
    self.actionButton = [[UIView alloc] initWithFrame:CGRectMake(self.tempSize.width * 3 / 4, 0.0, self.tempSize.width / 4, 44)];
    self.actionButton.backgroundColor = [UIColor yellowColor];
    // Add actionButtonTap
    if (!self.actionButtonTap) {
        self.actionButtonTap = [[UITapGestureRecognizer alloc] init];
    }
    [self.actionButton addGestureRecognizer:self.actionButtonTap];
    [self.keyboardSlot addSubview:self.actionButton];
    
    [self registerForKeyboardNotifications];
    
    // myTableViewController must be initialized before this
    self.myTableViewController.managedObjectContext = self.managedObjectContext;
    self.myTableViewController.managedObjectModel = self.managedObjectModel;
    self.myTableViewController.persistentStoreCoordinator =self.persistentStoreCoordinator;
    
    self.myTableViewController.tagsSelected = self.tagsSelected;
    
    [self addChildViewController:self.myTableViewController];
    [self.view addSubview:self.myTableViewController.view];
    [self.myTableViewController didMoveToParentViewController:self];
    
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    [self addNewInTable:self.myTableViewController withFetchedResultsController:self.myTableViewController.fetchedResultsController testKey:self.myTableViewController.cellTitle];
    return YES;
}

- (void)addNewInTable:(TVTableViewController *)tableController withFetchedResultsController:(NSFetchedResultsController *)fetchedResultsController testKey:(NSString *)key
{
    BOOL noOneMatched = YES;
    // The new one should not match the existing ones in table.
    // Test if anyone in persistent store matched
    for (NSManagedObject *obj in fetchedResultsController.fetchedObjects) {
        if (self.addTextField.text == [obj valueForKey:key]) {
            // Change the flag.
            noOneMatched = NO;
            // Show alert and do not save the new tag.
            break;
        };
    }
    
    if (noOneMatched == YES) {
        // If tempAddedRowsIsOn is YES, this action will only add a new string to the tempAddedTags (see TVTableViewController)
        if (self.tempAddedRowsIsOn == YES && (![self.addTextField.text isEqualToString:@""])) {
            // Add the tempAddedTags
            if (!tableController.tempAddedRows) {
                tableController.tempAddedRows = [NSMutableArray arrayWithCapacity:1];
            }
            [self addNewToTempAddedRows];
        }
        else if (!self.tempAddedRowsIsOn) {
            // No tempAdded objs
            if ([tableController.myEntityName isEqualToString:@"TVTag"]) {
                TVTag *tag = (TVTag *)[NSEntityDescription insertNewObjectForEntityForName:tableController.myEntityName inManagedObjectContext:self.managedObjectContext];
                tag.createdAt = [NSDate date];
                tag.tagName = self.addTextField.text;
                // Waiting for userName part finished
                tag.createdBy = @"user";
            }
            if ([tableController.myEntityName isEqualToString:@"TVContact"]) {
                // Adding new for contact only triggers sending a request to become contact to the contact. So create a TVActivity object here.
                // When user does this in sharing, system will take another step: store the tag and related cards as for existing contacts.
                TVActivity *activitySendingContactRequest = (TVActivity *)[NSEntityDescription insertNewObjectForEntityForName:@"TVActivity" inManagedObjectContext:self.managedObjectContext];
                activitySendingContactRequest.action = @"sendingContactRequest";
                activitySendingContactRequest.emailAddress = self.addTextField.text;
                activitySendingContactRequest.timeStamp = [NSDate date];
                // When another step needed to send tag
                if (self.addContactAndSendingTag == YES) {
                    TVActivity *activitySendingTag = (TVActivity *)[NSEntityDescription insertNewObjectForEntityForName:@"TVActivity" inManagedObjectContext:self.managedObjectContext];
                    activitySendingTag.action = @"sendingTag";
                    activitySendingTag.emailAddress = self.addTextField.text;
                    activitySendingTag.timeStamp = [NSDate date];
                    // activitySendingTag.tag =
                }
            }
            
            NSError *error = nil;
            if (![self.managedObjectContext save:&error]) {
                // Handle the error.
                UIAlertView *myTest = [[UIAlertView alloc] initWithTitle:@"Save error" message:@"failed" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil];
                [myTest show];
            }
        }
        // Refresh table
        [tableController refreshTableWithNoOptionalArray];
    }
}

- (void)longPressToEdit
{
    
}

#pragma mark - Keyboard & inputField movement sync

// Register for keyboard notification
- (void)registerForKeyboardNotifications
{

//     [[NSNotificationCenter defaultCenter] addObserver:self
//     selector:@selector(willShow:)
//     name:UIKeyboardWillShowNotification object:nil];
//     
//     [[NSNotificationCenter defaultCenter] addObserver:self
//     selector:@selector(didShow:)
//     name:UIKeyboardDidShowNotification object:nil];
//     
     [[NSNotificationCenter defaultCenter] addObserver:self
     selector:@selector(keyboardWillHide:)
     name:UIKeyboardWillHideNotification object:nil];
//
//     [[NSNotificationCenter defaultCenter] addObserver:self
//     selector:@selector(didHide:)
//     name:UIKeyboardDidHideNotification object:nil];
//     
//     
//     [[NSNotificationCenter defaultCenter] addObserver:self
//     selector:@selector(didChange:)
//     name:UIKeyboardDidChangeFrameNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillChange:)
                                                 name:UIKeyboardWillChangeFrameNotification object:nil];
}


 //Keyboard position test:
// - (void)willShow:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bwillShowY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"willShowY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bwillShow %f", bkbSize.height);
// NSLog(@"willShow %f", kbSize.height);
// }
// 
// - (void)didShow:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bdidShowY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"didShowY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bdidShow %f", bkbSize.height);
// NSLog(@"didShow %f", kbSize.height);
// }
// 
// - (void)willHide:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bwillHideY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"willHideY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bwillHide %f", bkbSize.height);
// NSLog(@"willHide %f", kbSize.height);
// }
// 
// - (void)didHide:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bdidHideY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"didHideY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bdidHide %f", bkbSize.height);
// NSLog(@"didHide %f", kbSize.height);
// }

// - (void)willChange:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bwwillChangeY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"willChangeY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bwillChange %f", bkbSize.height);
// NSLog(@"willChange %f", kbSize.height);
// }
// 
// - (void)didChange:(NSNotification*)aNotification
// {
// NSDictionary* info = [aNotification userInfo];
// 
// CGSize bkbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
// NSLog(@"bdidChangeY %f", [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].origin.y);
// 
// 
// CGSize kbSize = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
// NSLog(@"didChangeY %f", [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin.y);
// NSLog(@"bdidChange %f", bkbSize.height);
// NSLog(@"didChange %f", kbSize.height);
// }



- (void)keyboardWillChange:(NSNotification *)aNotification
{
    // Change event will be called very time
    NSDictionary* info = [aNotification userInfo];
    // Target at the end value instead of the begin value, end value is the one the keyboard is targeting on. keyboard's size won't change, so use the origin to track the movement of the keyboard
    CGPoint kbOrigin = [[info objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].origin;
    // Use screen size instead of the application's, coz keyboard is on UIScreen which covers the status bar as well
    // Change keyboardSlot's height when keyboard is triggered first time
    if (self.keyboardSlot.frame.size.height == 44.0) {
        // KeyboardSlot should move up from the bottom
        CGFloat newKeyboardSlotHeight = [UIScreen mainScreen].bounds.size.height - (kbOrigin.y - self.addTextField.frame.size.height);
        TVView *view = (TVView *)[UIApplication sharedApplication].keyWindow.rootViewController.view;
        view.keyboardAndExtraHeight = newKeyboardSlotHeight;
        view.keyboardIsForBottomInput = YES;
        view.keyboardIsShown = YES;
        view.touchToDismissKeyboardIsOff = NO;
        self.keyboardSlot.frame = CGRectMake(0.0, self.tempSize.height - newKeyboardSlotHeight, self.tempSize.width, self.tempSize.height - kbOrigin.y + 44.0);
        self.addTextField.frame = CGRectMake(0.0, self.keyboardSlot.frame.size.height - 44.0, self.keyboardSlot.frame.size.width, 44.0);
//        self.actionButton.frame = CGRectMake(self.tempSize.width * 3 / 4, self.keyboardSlot.frame.size.height - 44.0, self.tempSize.width / 4, 44.0);
        self.actionButton.hidden = YES;
        [self.keyboardSlot.superview bringSubviewToFront:self.keyboardSlot];
        [self.keyboardSlot setContentOffset:CGPointMake(0.0, self.keyboardSlot.frame.size.height - 44.0) animated:YES];
    }
}

- (void)keyboardWillHide:(NSNotification *)aNotification
{
    [self.keyboardSlot setContentOffset:CGPointZero animated:YES];
    TVView *view = (TVView *)[UIApplication sharedApplication].keyWindow.rootViewController.view;
    view.keyboardIsForBottomInput = NO;
    view.keyboardIsShown = NO;
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    if ([scrollView isEqual:self.keyboardSlot]) {
        
        if (self.keyboardSlot.contentOffset.y == 0.0) {
            // Just moved to bottom
            // Shrink keyboardSlot after the scrolling animation finished
            self.keyboardSlot.frame = CGRectMake(0.0, self.tempSize.height - 44.0, self.tempSize.width, 44.0);
            if (self.myTableViewController.tableView.editing == YES) {
                self.addTextField.frame = CGRectMake(0.0, 0.0, self.tempSize.width * 3 / 4, 44.0);
                self.actionButton.hidden = NO;
//                self.actionButton.frame = CGRectMake(self.tempSize.width * 3 / 4, 0.0, self.tempSize.width / 4, 44.0);
            } else {
                self.addTextField.frame = CGRectMake(0.0, 0.0, self.tempSize.width, 44.0);
            }
//            NSLog(@"self.actionButton.frame.origin.x: %f", self.actionButton.frame.origin.x);
//            NSLog(@"self.actionButton.frame.origin.y: %f", self.actionButton.frame.origin.y);
//            NSLog(@"self.addTextField.frame.origin.y: %f", self.addTextField.frame.origin.y);
        } else {
            // Just moved to top
            
        }
    }
}

- (void)dismissNewKeyboard
{
    [self.view endEditing:YES];
    [self.keyboardSlot setContentOffset:CGPointZero animated:YES];
}

// Called when the UIKeyboardWillHideNotification is sent
//- (void)keyboardWillBeHidden:(NSNotification*)aNotification
//{
//[self.keyboardSlot setContentOffset:CGPointZero animated:YES];
//}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    // Increase the contentSize bottom to make the view able to scroll down
    
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [self.view endEditing:YES];
    // Trim text first
    NSString *trimmedText = [self trimInput:textField.text];
    textField.text = trimmedText;
}

// Add a new row to arrayDataSource
- (void)addNewToTempAddedRows
{
    if ([self.myTableViewController.myEntityName  isEqualToString:@"TVTag"]) {
        TVTag *tag = (TVTag *)[self createRecord:[TVTag class] recordInResponse:nil inContext:self.managedObjectContext withNewCardController:nil withNonCardController:self user:self.user];
        
        [self.myTableViewController.tempAddedRows addObject:tag];
        NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"createdAt" ascending:NO];
        NSArray *sortArray = [NSArray arrayWithObjects:sortDescriptor, nil];
        [self.myTableViewController.tempAddedRows sortUsingDescriptors:sortArray];
        // Insert the row in dataSource to update the dataSource since new temp row is always added at top(latest).
        [self.myTableViewController.arrayDataSource insertObject:tag atIndex:0];
        // Insert the cell
        [self.myTableViewController.tableView beginUpdates];
        NSIndexPath *topPath = [NSIndexPath indexPathForRow:0 inSection:0];
        [self.myTableViewController.tableView insertRowsAtIndexPaths:@[topPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.myTableViewController.tableView endUpdates];
        // Select the new added
        NSIndexPath *path = [NSIndexPath indexPathForRow:[self.myTableViewController.arrayDataSource indexOfObject:tag] inSection:0];
        [self.myTableViewController selectionActionAtPath:path];
        
        // TO DO: Will delete those unselected objs in tempAddedRows before proceed to save them in persistent store.
    }
    if ([self.myTableViewController.myEntityName  isEqualToString:@"TVContact"]) {
        NSEntityDescription *entityDescription = [NSEntityDescription entityForName:self.myTableViewController.myEntityName inManagedObjectContext:self.myTableViewController.managedObjectContext];
        TVContact *contact = [[TVContact alloc] initWithEntity:entityDescription insertIntoManagedObjectContext:self.myTableViewController.managedObjectContext];
        contact.emailAddress = self.addTextField.text;
        contact.timeAdded = [NSDate date];
        [self.myTableViewController.tempAddedRows addObject:contact];
        // Other info of contact should be added before being saved to persistent store
        // Potential second step to send tag to the contact
        [self.myTableViewController refreshTableWithNoOptionalArray];
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
