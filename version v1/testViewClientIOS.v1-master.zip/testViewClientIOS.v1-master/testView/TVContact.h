//
//  TVContact.h
//  testView
//
//  Created by Liwei Zhang on 2013-10-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "TVBase.h"


@interface TVContact : TVBase

@property (nonatomic, retain) NSString * emailAddress;
@property (nonatomic, retain) NSDate * timeAdded;
@property (nonatomic, retain) NSString * userDescription;

@end
