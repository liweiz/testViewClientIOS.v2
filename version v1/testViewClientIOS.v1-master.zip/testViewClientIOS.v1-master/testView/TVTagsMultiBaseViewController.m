//
//  TVTagsMultiBaseViewController.m
//  testView
//
//  Created by Liwei on 2013-09-04.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVTagsMultiBaseViewController.h"
#import "TVTagsMultiNonTabViewController.h"
#import "TVTagsMultiTabViewController.h"

@interface TVTagsMultiBaseViewController ()

@end

@implementation TVTagsMultiBaseViewController

@synthesize forTab;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.tempAddedRowsIsOn = YES;
        self.startWithEditMode = YES;
        if (self.forTab == YES) {
            self.myTableViewController.positionY = 44.0f;
        }
        else if (self.forTab == NO) {
            self.myTableViewController.positionY = 0.0f;
        }
    }
    return self;
}

- (void)viewDidLoad
{
    if (self.forTab == YES) {
        self.myTableViewController = [[TVTagsMultiTabViewController alloc] init];
    }
    else if (self.forTab == NO) {
        self.myTableViewController = [[TVTagsMultiNonTabViewController alloc] init];
    }
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
