//
//  TVCard.h
//  testView
//
//  Created by Liwei on 10/29/2013.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "TVBase.h"

@class TVTag, TVUser;

@interface TVCard : TVBase

@property (nonatomic, retain) NSDate * collectedAt;
@property (nonatomic, retain) NSString * context;
@property (nonatomic, retain) NSDate * createdAt;
@property (nonatomic, retain) NSString * createdBy;
@property (nonatomic, retain) NSString * detail;
@property (nonatomic, retain) NSString * sourceLang;
@property (nonatomic, retain) NSString * target;
@property (nonatomic, retain) NSString * targetLang;
@property (nonatomic, retain) NSString * translation;
@property (nonatomic, retain) NSSet *hasTag;
@property (nonatomic, retain) TVUser *collectedBy;
@end

@interface TVCard (CoreDataGeneratedAccessors)

- (void)addHasTagObject:(TVTag *)value;
- (void)removeHasTagObject:(TVTag *)value;
- (void)addHasTag:(NSSet *)values;
- (void)removeHasTag:(NSSet *)values;

@end
