//
//  UIViewController+sharedMethods.m
//  testView
//
//  Created by Liwei on 2013-08-08.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "UIViewController+sharedMethods.h"

@implementation UIViewController (sharedMethods)

#pragma mark - present another view back and forth

// Tap could be the gesture for visiting or exiting a visual layer
// LongPress is only for visiting the visual layer below
// For visiting a visual layer below
- (void)showNewView:(UIView *)newView newViewController:(UIViewController *)newController currentView:(UIView *)currentView baseView:(UIView *)base tapGesture:(UITapGestureRecognizer *)tapGesture longPressGesture:(UILongPressGestureRecognizer *)longPressGesture
{
    [currentView endEditing:YES];
    // If the view is inited with a viewController, please get the controller ready before executing this method
    if (tapGesture) {
        if (newController) {
            [self addChildViewController:newController];
        }
        CGPoint positionPoint = [tapGesture locationInView:base];
        CGPoint anchorPoint = CGPointMake(positionPoint.x / base.frame.size.width, positionPoint.y / base.frame.size.height);
        [self comeThrough:currentView anchorPoint:anchorPoint];
        [base insertSubview:newView belowSubview:currentView];
        [self comeUp:newView anchorPoint:anchorPoint];
        if (newController) {
            [newController didMoveToParentViewController:self];
        }
    }
    if (longPressGesture && longPressGesture.state == UIGestureRecognizerStateBegan) {
        if (newController) {
            [self addChildViewController:newController];
        }
        CGPoint positionPoint = [longPressGesture locationInView:base];
//        NSLog(@"location in base x: %f", positionPoint.x);
//        NSLog(@"location in base y: %f", positionPoint.y);
        CGPoint anchorPoint = CGPointMake(positionPoint.x / base.frame.size.width, positionPoint.y / base.frame.size.height);
//        NSLog(@"anchor x: %f", anchorPoint.x);
//        NSLog(@"anchor y: %f", anchorPoint.y);
        [self comeThrough:currentView anchorPoint:anchorPoint];
        [base insertSubview:newView belowSubview:currentView];
        [self comeUp:newView anchorPoint:anchorPoint];
        if (newController) {
            [newController didMoveToParentViewController:self];
        }
    }
}

// Keep the newController in hierarchy, so no newController argument here
// No longPress here, either. However, pinchGesture could be here for exiting the new visual layer
- (void)hideNewView:(UIView *)newView currentView:(UIView *)currentView baseView:(UIView *)base tapGesture:(UITapGestureRecognizer *)tapGesture pinchGesture:(UIPinchGestureRecognizer *)pinchGesture
{
    [newView endEditing:YES];
    if (tapGesture) {
        CGPoint positionPoint = [tapGesture locationInView:base];
        CGPoint anchorPoint = CGPointMake(positionPoint.x / base.frame.size.width, positionPoint.y / base.frame.size.height);
        [self goThrough:currentView anchorPoint:anchorPoint];
        [base insertSubview:newView belowSubview:currentView];
        [self goDown:newView anchorPoint:anchorPoint];
    }
    if (pinchGesture && (pinchGesture.state == UIGestureRecognizerStateBegan)) {
        if (pinchGesture.scale < 1.0) {
            // The last locations
            CGPoint lastLocation0 = [pinchGesture locationOfTouch:0 inView:base];
            CGPoint lastLocation1 = [pinchGesture locationOfTouch:1 inView:base];
            CGPoint middlePoint = CGPointMake((lastLocation0.x + lastLocation1.x) / 2, (lastLocation0.y + lastLocation1.y) / 2);
            CGPoint anchorPoint = CGPointMake(middlePoint.x / base.frame.size.width, middlePoint.y / base.frame.size.height);
            [self goThrough:currentView anchorPoint:anchorPoint];
            [base insertSubview:newView belowSubview:currentView];
            [self goDown:newView anchorPoint:anchorPoint];
        }
    }
}

- (void)comeThrough:(UIView *)view anchorPoint:(CGPoint)point
{
    CABasicAnimation *becomeTransparent = [CABasicAnimation animationWithKeyPath:@"opacity"];
    becomeTransparent.fromValue = [NSNumber numberWithFloat:1.0];
    becomeTransparent.toValue = [NSNumber numberWithFloat:0.0];
    becomeTransparent.duration = 0.5;
    
    CABasicAnimation *becomeLarge = [CABasicAnimation animationWithKeyPath:@"transform"];
    becomeLarge.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    becomeLarge.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(3, 3, 1)];;
    becomeLarge.duration = 0.5;
    
    CAAnimationGroup *comeThrough = [CAAnimationGroup animation];
    comeThrough.animations = [NSArray arrayWithObjects:becomeLarge, becomeTransparent, nil];
    comeThrough.duration = 0.5;
    comeThrough.delegate = self;
    // Keep the animation before hidden is set to avoid flashing back after the completion of the animiation while hidden is not set.
    comeThrough.fillMode = kCAFillModeForwards;
    comeThrough.removedOnCompletion = NO;
    
    // Get the anchorPoint and positionPoint before animating
    CGPoint lastAnchorPoint = view.layer.anchorPoint;
    CGPoint lastPositionPoint = view.layer.position;
    // Reset the anchorPoint and positionPoint by user's touch
    view.layer.anchorPoint = point;
    view.layer.position = CGPointMake(view.bounds.size.width * (point.x - lastAnchorPoint.x) + lastPositionPoint.x,view.bounds.size.height * (point.y - lastAnchorPoint.y) + lastPositionPoint.y);
    
    [comeThrough setValue:@"comeThrough" forKey:@"animationName"];
    
    [view.layer addAnimation:comeThrough forKey:@"comeThrough"];
    
}

- (void)comeUp:(UIView *)view anchorPoint:(CGPoint)point
{
    CABasicAnimation *becomeOpaque = [CABasicAnimation animationWithKeyPath:@"opacity"];
    becomeOpaque.fromValue = [NSNumber numberWithFloat:0.0];
    becomeOpaque.toValue = [NSNumber numberWithFloat:1.0];
    becomeOpaque.duration = 0.5;
    
    CABasicAnimation *becomeLarger = [CABasicAnimation animationWithKeyPath:@"transform"];
    becomeLarger.fromValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.4, 0.4, 1)];
    becomeLarger.toValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];;
    becomeLarger.duration = 0.5;
    
    CAAnimationGroup *comeUp = [CAAnimationGroup animation];
    comeUp.animations = [NSArray arrayWithObjects:becomeLarger, becomeOpaque, nil];
    comeUp.duration = 0.5;
    comeUp.delegate = self;
    
    // Get the anchorPoint and positionPoint before animating
    CGPoint lastAnchorPoint = view.layer.anchorPoint;
    CGPoint lastPositionPoint = view.layer.position;
    // Reset the anchorPoint and positionPoint by user's touch
    view.layer.anchorPoint = point;
    view.layer.position = CGPointMake(view.bounds.size.width * (point.x - lastAnchorPoint.x) + lastPositionPoint.x,view.bounds.size.height * (point.y - lastAnchorPoint.y) + lastPositionPoint.y);
    
    [comeUp setValue:@"comeUp" forKey:@"animationName"];
    
    [view.layer addAnimation:comeUp forKey:@"comeUp"];
    
}

- (void)goThrough:(UIView *)view anchorPoint:(CGPoint)point
{
    CABasicAnimation *becomeOpaque = [CABasicAnimation animationWithKeyPath:@"opacity"];
    becomeOpaque.fromValue = [NSNumber numberWithFloat:0.0];
    becomeOpaque.toValue = [NSNumber numberWithFloat:1.0];
    becomeOpaque.duration = 0.5;
    
    CABasicAnimation *becomeSmall = [CABasicAnimation animationWithKeyPath:@"transform"];
    becomeSmall.fromValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(3, 3, 1)];
    becomeSmall.toValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];;
    becomeSmall.duration = 0.5;
    
    CAAnimationGroup *goThrough = [CAAnimationGroup animation];
    goThrough.animations = [NSArray arrayWithObjects:becomeSmall, becomeOpaque, nil];
    goThrough.duration = 0.5;
    goThrough.delegate = self;
    goThrough.fillMode = kCAFillModeForwards;
    goThrough.removedOnCompletion = NO;
    
    // Get the anchorPoint and positionPoint before animating
    CGPoint lastAnchorPoint = view.layer.anchorPoint;
    CGPoint lastPositionPoint = view.layer.position;
    // Reset the anchorPoint and positionPoint by user's touch
    view.layer.anchorPoint = point;
    view.layer.position = CGPointMake(view.bounds.size.width * (point.x - lastAnchorPoint.x) + lastPositionPoint.x,view.bounds.size.height * (point.y - lastAnchorPoint.y) + lastPositionPoint.y);
    
    [goThrough setValue:@"goThrough" forKey:@"animationName"];
    
    [view.layer addAnimation:goThrough forKey:@"goThrough"];
    
}

- (void)goDown:(UIView *)view anchorPoint:(CGPoint)point
{
    CABasicAnimation *becomeTransparent = [CABasicAnimation animationWithKeyPath:@"opacity"];
    becomeTransparent.fromValue = [NSNumber numberWithFloat:1.0];
    becomeTransparent.toValue = [NSNumber numberWithFloat:0.0];
    becomeTransparent.duration = 0.5;
    //self.becomeTransparent.removedOnCompletion = NO;
    
    CABasicAnimation *becomeSmaller = [CABasicAnimation animationWithKeyPath:@"transform"];
    becomeSmaller.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    becomeSmaller.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.4, 0.4, 1)];;
    becomeSmaller.duration = 0.5;
    //self.becomeSmaller.removedOnCompletion = NO;
    
    CAAnimationGroup *goDown = [CAAnimationGroup animation];
    goDown.animations = [NSArray arrayWithObjects:becomeSmaller, becomeTransparent, nil];
    goDown.duration = 0.5;
    goDown.delegate = self;
    
    // Get the anchorPoint and positionPoint before animating
    CGPoint lastAnchorPoint = view.layer.anchorPoint;
    CGPoint lastPositionPoint = view.layer.position;
    // Reset the anchorPoint and positionPoint by user's touch
    view.layer.anchorPoint = point;
    view.layer.position = CGPointMake(view.bounds.size.width * (point.x - lastAnchorPoint.x) + lastPositionPoint.x,view.bounds.size.height * (point.y - lastAnchorPoint.y) + lastPositionPoint.y);
    
    [goDown setValue:@"goDown" forKey:@"animationName"];
    
    [view.layer addAnimation:goDown forKey:@"goDown"];
    
}

#pragma mark - remove blank spaces at the beginning and end of any input
- (NSString *)trimInput:(NSString *)text
{
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [text stringByTrimmingCharactersInSet:whitespace];
    return trimmed;
}

#pragma mark - pre-selection action
- (void)preselectFromSet:(NSSet *)set inTableViewController:(TVTableViewController *)tableViewController
{
    for (NSManagedObject *obj in set) {
        NSIndexPath *path = [NSIndexPath indexPathForRow:[tableViewController.arrayDataSource indexOfObject:obj] inSection:0];
        [tableViewController selectionActionAtPath:path];
        // reloadRowsAtIndexPaths leads to clearing everything in selection, so not able to be used here
        TVTableViewCell *cell = (TVTableViewCell *)[tableViewController.tableView cellForRowAtIndexPath:path];
        if (cell) {
            [tableViewController configureStatusCodeForCell:cell atIndexPath:path];
            [cell updateEditView];
        }
    }
}

#pragma mark - targetTable multiselection dataSource based on pre-selection
// This is for newView tagSelection
// There are three parts: 1. pre-selected 2. unselected 3. new
// New is added with defalut tableView arrayDataSource procedure
// So only combine reorder the pre-selected/unselected here
- (NSArray *)getDataSourceReadyFromDataSource:(NSArray *)array withPreselectedSet:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor
{
    NSArray *preselectedArray = [self getPreselectedArray:preselectedSet sortDescriptor:sortDescriptor];
    NSArray *unselectedArray = [self getUnselectedArrayFromDataSource:array withPreselectedSet:preselectedSet sortDescriptor:sortDescriptor];
    NSMutableArray *fullArray = [NSMutableArray arrayWithArray:preselectedArray];
    [fullArray addObjectsFromArray:unselectedArray];
    return fullArray;
}

- (NSArray *)getPreselectedArray:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor
{
    return [preselectedSet sortedArrayUsingDescriptors:@[sortDescriptor]];
}

- (NSArray *)getUnselectedArrayFromDataSource:(NSArray *)array withPreselectedSet:(NSSet *)preselectedSet sortDescriptor:(NSSortDescriptor *)sortDescriptor
{
    NSMutableSet *allSet = [NSMutableSet setWithArray:array];
    [allSet minusSet:preselectedSet];
    return [allSet sortedArrayUsingDescriptors:@[sortDescriptor]];
}

#pragma mark - targetTable multiselection dataSource from originTableView
// There will be four parts: 1. selected 2. unselected 3. partly selected 4. new
// New is added with defalut tableView arrayDataSource procedure

// Form the complete array, a different fetchedResultsController is used here.
- (NSArray *)getTargetTableDataSourceArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor targetFetchedResultsController:(NSFetchedResultsController *)newFetchedResultsController
{
    NSArray *unselectedSetArray = [self getTargetTableDataSourceUnselectedArrayForEditModeFromOriginalTable:tableView fetchedResultsController:fetchedResultsController byRelationshipCountKey:key additionalSortDescripter:sortDescriptor targetFetchedResultsController:newFetchedResultsController];
    NSArray *fullySelectedSetArray = [self getTargetTableDataSourceFullySelectedArrayForEditModeFromOriginalTable:tableView fetchedResultsController:fetchedResultsController byRelationshipCountKey:key additionalSortDescripter:sortDescriptor];
    NSArray *partlySelectedSetArray = [self getTargetTableDataSourcePartlySelectedArrayForEditModeFromOriginalTable:tableView fetchedResultsController:fetchedResultsController byRelationshipCountKey:key additionalSortDescripter:sortDescriptor];
    NSMutableArray *allArray = [NSMutableArray arrayWithCapacity:1];
    [allArray addObjectsFromArray:fullySelectedSetArray];
    [allArray addObjectsFromArray:partlySelectedSetArray];
    [allArray addObjectsFromArray:unselectedSetArray];
    return allArray;
}

// Turn unselectedSet to the array
- (NSArray *)getTargetTableDataSourceUnselectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor targetFetchedResultsController:(NSFetchedResultsController *)newFetchedResultsController
{
    NSMutableSet *allSet = [NSMutableSet setWithCapacity:1];
    [allSet addObjectsFromArray:newFetchedResultsController.fetchedObjects];
    [allSet minusSet:[self getTargetTableDataSourceSelectedSetForEditMode:tableView fetchedResultsController:fetchedResultsController byRelationshipKey:key]];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
    NSArray *unselectedSetArray = [allSet sortedArrayUsingDescriptors:sortDescriptors];
    return unselectedSetArray;
}

// Turn fullySelectedSet to the array
- (NSArray *)getTargetTableDataSourceFullySelectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor
{
    NSMutableSet *fullySelectedSet = [self getFullySelectedSetFromOriginalTable:tableView fetchedResultsController:fetchedResultsController byRelationshipKey:key];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:sortDescriptor, nil];
    NSArray *partlySelectedSetArray = [fullySelectedSet sortedArrayUsingDescriptors:sortDescriptors];
    return partlySelectedSetArray;
}

// Turn partlySelectedSet to the array
- (NSArray *)getTargetTableDataSourcePartlySelectedArrayForEditModeFromOriginalTable:(UITableView *)tableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipCountKey:(NSString *)key additionalSortDescripter:(NSSortDescriptor *)sortDescriptor
{
    NSMutableSet *partlySelectedSet = [self getPartlySelectedSetFromOriginalTable:tableView fetchedResultsController:fetchedResultsController byRelationshipKey:key];
    NSSortDescriptor *byCount = [NSSortDescriptor sortDescriptorWithKey:key ascending:NO comparator:^(id obj1, id obj2) {
        NSInteger obj1Value = [self uniqueCount:obj1 byRelationshipKey:key];
        NSInteger obj2Value = [self uniqueCount:obj2 byRelationshipKey:key];
        if (obj1Value > obj2Value) {
            return (NSComparisonResult)NSOrderedDescending;
        }
        if (obj1Value < obj2Value) {
            return (NSComparisonResult)NSOrderedAscending;
        }
        return (NSComparisonResult)NSOrderedSame;
    }];
    NSArray *sortDescriptors = [NSArray arrayWithObjects:byCount, sortDescriptor, nil];
    NSArray *partlySelectedSetArray = [partlySelectedSet sortedArrayUsingDescriptors:sortDescriptors];
    return partlySelectedSetArray;
}

// Get the partly selected set
- (NSMutableSet *)getPartlySelectedSetFromOriginalTable:(UITableView *)table fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key
{
    NSMutableSet *selectedTargetSet = [self getTargetTableDataSourceSelectedSetForEditMode:table fetchedResultsController:fetchedResultsController byRelationshipKey:key];
    NSMutableSet *fullySelectedSet = [self getFullySelectedSetFromOriginalTable:table fetchedResultsController:fetchedResultsController byRelationshipKey:key];
    [selectedTargetSet minusSet:fullySelectedSet];
    return selectedTargetSet;
}

// Get the fully selected set
- (NSMutableSet *)getFullySelectedSetFromOriginalTable:(UITableView *)table fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key
{
    NSMutableSet *selectedTargetSet = [self getTargetTableDataSourceSelectedSetForEditMode:table fetchedResultsController:fetchedResultsController byRelationshipKey:key];
    NSMutableSet *fullySelectedSet = [NSMutableSet setWithCapacity:1];
    NSMutableSet *partlySelectedSet = [NSMutableSet setWithCapacity:1];
    NSMutableSet *originalSelectedSet = [self getOriginalManagedObjects:table fetchedResultsController:fetchedResultsController];
    for (NSManagedObject *obj in originalSelectedSet) {
        if ([[obj mutableSetValueForKey:key] isEqualToSet:selectedTargetSet]) {
            [fullySelectedSet addObject:obj];
        } else {
            [partlySelectedSet addObject:obj];
        }
    }
    return fullySelectedSet;
}

// Each selected managedObject's relationship count is not more than the union of all the selected ones'.
- (NSInteger)uniqueCount:(NSManagedObject *)managedObject byRelationshipKey:(NSString *)key
{
    NSInteger countResult = [[managedObject mutableSetValueForKey:key] count];
    return countResult;
}

// Get the corresponding selected set in targetTableView
- (NSMutableSet *)getTargetTableDataSourceSelectedSetForEditMode:(UITableView *)originTableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController byRelationshipKey:(NSString *)key
{
    NSSet *myOriginalManagedObjects = [self getOriginalManagedObjects:originTableView fetchedResultsController:fetchedResultsController];
    NSMutableSet *selectedSet = [NSMutableSet setWithCapacity:1];
    // Get the non-duplicate NSManagedObjects set for targetTable dataSource
    // At this point, for tag only
    if ([key isEqualToString:@"hasCard"]) {
        for (TVTag *obj in myOriginalManagedObjects) {
            [selectedSet unionSet:obj.hasCard];
        }
    }
    if ([key isEqualToString:@"hasTag"]) {
        for (TVCard *obj in myOriginalManagedObjects) {
            [selectedSet unionSet:obj.hasTag];
        }
    }
    return selectedSet;
}

// Get the origin selected set in originTableView
- (NSMutableSet *)getOriginalManagedObjects:(UITableView *)originTableView fetchedResultsController:(NSFetchedResultsController *)fetchedResultsController
{
    NSMutableSet *myMutableSet;
    // Get the selected NSManagedObjects in originTableView as a set
    for (NSIndexPath *obj in originTableView.indexPathsForSelectedRows) {
        if (!myMutableSet) {
            myMutableSet = [NSMutableSet setWithCapacity:1];
        }
        [myMutableSet addObject:[fetchedResultsController objectAtIndexPath:obj]];
    }
    return myMutableSet;
}

#pragma mark - multiselection and save

// multiselection tableViewCell has three statuses: 0: unselected, 1: fully selected, 2: partly selected

// Generate a NSSet of NSManagedObjects for next step's adding/removing operation
// Get the changed set from TVTableViewController.changeMadeSet
- (void)changeSet:(NSSet *)changeSet relationshipKey:(NSString *)key selectionSetOrigin:(NSSet *)originSet
{
    for (NSMutableArray *obj in changeSet) {
        if ([[obj lastObject] integerValue] == 1) {
            // To be added: origin status is 0 or 2, final status is 1
            [[[obj firstObject] mutableSetValueForKey:key] unionSet:originSet];
        } else if ([[obj lastObject] integerValue] == 0) {
            // To be removed: origin status is 1 or 2, final status is 0
            [[[obj firstObject] mutableSetValueForKey:key] minusSet:originSet];
        }
    }
}

- (void)saveMultiselectionChange:(NSManagedObjectContext *)managedObjectContext
{
    NSError *error = nil;
    if (![managedObjectContext save:&error]) {
        // Handle the error.
        UIAlertView *myTest = [[UIAlertView alloc] initWithTitle:@"Save error" message:@"failed" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil];
        [myTest show];
    }
}

#pragma mark - horizontal scrolling freeze/defreeze

// Freeze the rootView's horizontally scrolling
- (void)freezeRootView
{
    UIScrollView *rootScrollView = (UIScrollView *)[[UIApplication sharedApplication].keyWindow.rootViewController.view viewWithTag:555];
    rootScrollView.scrollEnabled = NO;
}

// Enable the rootView's horizontally scrolling
- (void)defreezeRootView
{
    UIScrollView *rootScrollView = (UIScrollView *)[[UIApplication sharedApplication].keyWindow.rootViewController.view viewWithTag:555];
    rootScrollView.scrollEnabled = YES;
}

#pragma mark - sync action utilities
// Get rootViewController
- (TVAppRootViewController *)getAppRootViewController
{
    return (TVAppRootViewController *)[[[UIApplication sharedApplication] keyWindow] rootViewController];
}

// NSDate <=> NSString JSON date string http://en.wikipedia.org/wiki/ISO_8601 e.g., 2013-09-29T10:40Z
- (NSString *)convertNSDate:(NSDate *)date
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSLocale *enUSPOSIXLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormatter setLocale:enUSPOSIXLocale];
    [dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssZ"];
    
    return [dateFormatter stringFromDate:date];
}

- (NSDate *)convertISO8601String:(NSString *)string
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSLocale *enUSPOSIXLocale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [formatter setLocale:enUSPOSIXLocale];
    [formatter setDateFormat:@"yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'"];
    return [formatter dateFromString:string];
}

// NSManagedObject <=> NSDictionary
- (NSDictionary *)convertNSManagedObjToDict:(TVBase *)record withEntityDescription:(NSEntityDescription *)description
{
    NSMutableDictionary *recordDict = [NSMutableDictionary dictionaryWithSharedKeySet:[NSDictionary sharedKeySetForKeys:description.attributesByName.allKeys]];
    for (NSString *aKey in description.attributesByName.allKeys) {
        if ([record valueForKey:aKey]) {
            // Not nil
            if ([[record valueForKey:aKey] isKindOfClass:[NSDate class]]) {
                [recordDict setObject:[self convertNSDate:[record valueForKey:aKey]] forKey:aKey];
            } else {
                [recordDict setObject:[record valueForKey:aKey] forKey:aKey];
            }
        } else {
            // Nil, assign Null
            [recordDict setObject:[NSNull null] forKey:aKey];
        }
    }
    for (NSString *aRelationship in description.relationshipsByName.allKeys) {
        if ([aRelationship isEqualToString:@"collectedBy"]) {
            // Could be email NSString/serverID NSNumber to stand for user here
            [recordDict setValue:[[record valueForKey:@"collectedBy"] valueForKey:@"email"] forKey:aRelationship];
        } else {
            // User's hasCards is not sync here, so no need to prepare that so far
            // JUST ASSIGN NULL, WILL CHANGE ONCE TAG IS INTRODUCED
            [recordDict setValue:[NSNull null] forKey:aRelationship];
        }
    }
    return recordDict;
}

- (TVBase *)convertDict:(NSDictionary *)recordDict toNSManagedObj:(TVBase *)record
{
    for (NSString *aKey in recordDict.allKeys) {
        if ([recordDict valueForKey:aKey] != [NSNull null]) {
            // Not null in JSON, not NSNull in NSDictionary
            // NSDate?
            NSArray *dateKeys = @[@"lastModifiedAtLocal", @"lastModifiedAtServer", @"collectedAt", @"createdAt", @"timeAdded", @"timeStamp"];
            for (NSString *dateKey in dateKeys) {
                if ([aKey isEqualToString:dateKey]) {
                    // Convert to NSDate, if not nil
                    NSString *dateString = [recordDict valueForKey:aKey];
                    if (dateString.length > 0) {
                        // Not nil
                        [record setValue:[self convertISO8601String:dateString] forKey:aKey];
                    } else {
                        // Nil
                        [record setValue:nil forKey:aKey];
                    }
                }
            }
            // Standing for relationships?
            NSArray *relationshipKeys = @[@"hasTag", @"hasCard", @"hasCards"];
            for (NSString *relationshipKey in relationshipKeys) {
                // There is no nil for relationship set, only empty set
                if ([aKey isEqualToString:relationshipKey]) {
                    NSSet *theRelationships = [NSSet setWithArray:[recordDict valueForKey:aKey]];
                    [[record mutableSetValueForKey:relationshipKey] setSet:theRelationships];
                }
            }
            if ([aKey isEqualToString:@"collectedBy"]) {
                TVAppRootViewController *myRootViewController = [self getAppRootViewController];
                [record setValue:myRootViewController.user forKey:@"collectedBy"];
            }
        } else {
            // Nil
            [record setValue:nil forKey:aKey];
        }
    }
    return record;
}

- (void)handleConnectionError:(ConnectionErrorStatus)errorStatus
{
    switch (errorStatus) {
        case ServerNotAvailable:
            [self showAlertForMessage:@"Please make sure the internet service is available and try again." title:@"No Connection"];
            break;
        case AccountAlreadyExists:
            [self showAlertForMessage:@"This e-mail is already taken." title:@"Sign Up Not Successful"];
            break;
        case IncorrectAccountNameOrPassword:
            [self showAlertForMessage:@"Invalid e-mail or password." title:@"Sign In Not Successful"];
            break;
        case NoDataDownloaded:
            [self showAlertForMessage:@"Please try again later." title:@"Connection Not Successful"];
            break;
        case TimeOut:
            [self showAlertForMessage:@"Please try again later." title:@"Time Out"];
            break;
        case NoSuchAccountExists:
            [self showAlertForMessage:@"No account with that e-mail address exists." title:@"Not Able to Reset Password"];
            break;
        case OtherError:
            [self showAlertForMessage:@"" title:@"Error"];
            break;
        default:
            break;
    }
}

- (void)showAlertForMessage:(NSString *)message title:(NSString *)title
{
    UIAlertView *myTest = [[UIAlertView alloc] initWithTitle:@"Save error" message:@"failed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [myTest show];
}

#pragma mark - sync action response
// Action based on HTTP code
- (BOOL)statusCheckForResponse:(NSHTTPURLResponse *)response
{
    if (response.statusCode == 200) {
        return YES;
    } else {
        return NO;
    }
}

// Process the JSON from response
- (BOOL)handleLoginResponse:(NSHTTPURLResponse *)response withData:(NSData *)data
{
    // Login response returns a new token and after the token is saved to keychain and , a new request is launched automatically
    // to execute the general data sync process
    if ([self savePassToKeychainFromResponse:response withData:data]) {
        // Valid token received, proceed to dataSync
        NSSet *entitySet = [NSSet setWithObject:@"TVCard"];
        NSDictionary *rootDict = [self getDictFromResponse:response withData:data];
        NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:@"TVUser"];
        // NEED TO TEST
        NSPredicate *predicateAction = [NSPredicate predicateWithFormat:@"email like %@", [rootDict valueForKey:@"email"]];
        [request setPredicate:predicateAction];
        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastModifiedAtLocal" ascending:YES];
        [request setSortDescriptors:@[sortDescriptor]];
        NSArray *userArray = [[self getAppRootViewController].managedObjectContext executeFetchRequest:request error:nil];
        // Get setup user
        TVUser *user;
        if ([userArray count] > 0) {
            // The user exists in local, no need to get the user from response
            user = [userArray objectAtIndex:0];
        } else {
            // No user exists in local, need to get the user from response
            user = (TVUser *)[self createRecord:[TVUser class] recordInResponse:[rootDict valueForKey:@"user"] inContext:[self getAppRootViewController].managedObjectContext withNewCardController:nil withNonCardController:nil user:nil];
            // Commit the changes in persistence store
            [self proceedChangesInContext:[self getAppRootViewController].managedObjectContext willSendRequest:NO];
        }
        // Send dataSync request once the user logs in successfully
        [self startSyncEntitySet:entitySet withNewCardController:nil user:user];
        return YES;
    } else {
        // No token received, need to sign in again
        return NO;
    }
}

- (BOOL)savePassToKeychainFromResponse:(NSHTTPURLResponse *)response withData:(NSData *)data
{
    NSDictionary *rootDict = [self getDictFromResponse:response withData:data];
    if ([(NSString *)[rootDict valueForKey:@"pass"] length] > 0) {
        // NEED TO UPDATE @"YOUR_APP_ID_HERE.com.yourcompany.GenericKeychainSuite"
        KeychainItemWrapper *pass = [[KeychainItemWrapper alloc] initWithAccount:[rootDict valueForKey:@"email"] service:nil accessGroup:nil];
        [pass setObject:[rootDict valueForKey:@"pass"] forKey:(__bridge id)kSecValueData];
        return YES;
    } else {
        return NO;
    }
}

- (NSString *)getPassFromKeychainEmail:(NSString *)email
{
    // NEED TO UPDATE @"YOUR_APP_ID_HERE.com.yourcompany.GenericKeychainSuite"
    KeychainItemWrapper *pass = [[KeychainItemWrapper alloc] initWithAccount:email service:nil accessGroup:nil];
    return [pass objectForKey:(__bridge id)kSecValueData];
}

- (void)handleDataSyncResponse:(NSHTTPURLResponse *)response withData:(NSData *)data user:(TVUser *)user withNewCardController:(TVNewBaseViewController *)controller
{
    NSDictionary *rootDict = [self getDictFromResponse:response withData:data];
    [self processEntity:@"TVCard" inContext:user.managedObjectContext withNewCardController:controller withNonCardController:nil user:user rootResponse:rootDict];
}

- (NSDictionary *)getDictFromResponse:(NSHTTPURLResponse *)response withData:(NSData *)data
{
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
    return dict;
}

- (void)processEntity:(NSString *)entityName inContext:(NSManagedObjectContext *)context withNewCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user rootResponse:(NSDictionary *)rootResponse
{
    NSDictionary *dict;
    if ([entityName isEqualToString:@"TVCard"]) {
        NSArray *localCards = [self getLocalRecordsForEntityName:@"TVCard" user:user];
        dict = [self categorizeCreateUpdateDeleteInRecords:[rootResponse valueForKey:@"card"] user:user inLocalEntity:localCards];
    }
    
    NSArray *entityToCreate = [dict valueForKey:@"create"];
    NSArray *entityToUpdate = [dict valueForKey:@"update"];
    NSArray *entityToDelete = [dict valueForKey:@"delete"];
    if ([entityToCreate count] > 0) {
        if ([entityName isEqualToString:@"TVCard"]) {
            for (NSDictionary *entityRecord in entityToCreate) {
                [self createRecord:[TVCard class] recordInResponse:entityRecord inContext:context withNewCardController:controller withNonCardController:nil user:user];
            }
            NSArray *toDelete = [self getArrayForSyncRequestWithEntityName:@"TVCard" forAction:@"create" inContext:context convertNSManagedObjToDict:NO];
            for (TVCard *obj in toDelete) {
                // A new record needs to be created on client, the uncommited one should be checked to delete
                [self createAfter:obj rootResponse:rootResponse];
            }
        }
    }
    if ([entityToUpdate count] > 0) {
        if ([entityName isEqualToString:@"TVCard"]) {
            for (NSDictionary *entityRecord in entityToUpdate) {
                TVCard *cardToUpdate = (TVCard *)[self getRecordForServerID:[entityRecord valueForKey:@"serverID"] WithEntityName:@"TVCard" inContext:context];
                [self updateRecord:cardToUpdate recordInResponse:entityRecord withCardController:controller withNonCardController:nil user:user];
            }
        }
    }
    if ([entityToDelete count] > 0) {
        if ([entityName isEqualToString:@"TVCard"]) {
            for (NSDictionary *entityRecord in entityToDelete) {
                TVCard *cardToDelete = (TVCard *)[self getRecordForServerID:[entityRecord valueForKey:@"serverID"] WithEntityName:@"TVCard" inContext:context];
                // Delete happens only when the record exists in local
                if (cardToDelete) {
                    [self commitDeleteRecord:cardToDelete];
                }
            }
        }
    }
    // Commit the changes in persistence store
    [self proceedChangesInContext:context willSendRequest:NO];
}

- (NSArray *)getLocalRecordsForEntityName:(NSString *)entityName user:(TVUser *)user
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:entityName];
    // NEED TO TEST
    NSPredicate *predicateAction = [NSPredicate predicateWithFormat:@"(%@ IN collectedBy)", user];
    [request setPredicate:predicateAction];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastModifiedAtLocal" ascending:YES];
    [request setSortDescriptors:@[sortDescriptor]];
    return [user.managedObjectContext executeFetchRequest:request error:nil];
}

- (TVBase *)getRecordForServerID:(NSNumber *)ID WithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:name];
    NSPredicate *predicateAction = [NSPredicate predicateWithFormat:@"serverID == %d", ID.integerValue];
    [request setPredicate:predicateAction];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastModifiedAtLocal" ascending:YES];
    [request setSortDescriptors:@[sortDescriptor]];
    NSArray *array = [context executeFetchRequest:request error:nil];
    return [array objectAtIndex:0];
}

- (NSDictionary *)categorizeCreateUpdateDeleteInRecords:(NSArray *)records user:(TVUser *)user inLocalEntity:(NSArray *)localRecords
{
    /*
     Server delivers records meet following criteria:
     1. versionNo greater than local user's highestLastSyncVersionNo
     2. for deleted ones on server, deliver those with versionNoInitial not greater than local user's highestLastSyncVersionNo and versionNo greater than local user's highestLastSyncVersionNo
     
     Filter through both versionNoInitial and versionNo.
     */
    // Firstly, check if server passes the right records
    NSMutableArray *toDelete = [NSMutableArray arrayWithCapacity:1];
    NSMutableArray *toCreate = [NSMutableArray arrayWithCapacity:1];
    NSMutableArray *toUpdate = [NSMutableArray arrayWithCapacity:1];
    for (TVBase *obj in records) {
        if (obj.deletedOnServer.boolValue == YES && obj.versionNoInitial.integerValue <= user.highestLastSyncVersionNo.integerValue && obj.versionNo.integerValue > user.highestLastSyncVersionNo.integerValue) {
            // Add to Delete array
            [toDelete addObject:obj];
        }
        else if (obj.deletedOnServer.boolValue == NO && obj.versionNo.integerValue > user.highestLastSyncVersionNo.integerValue) {
            // This is for create and update
            for (TVBase *localObj in localRecords) {
                if (obj.serverID.integerValue == localObj.serverID.integerValue) {
                    // There is a local record, update
                    [toUpdate addObject:obj];
                } else {
                    // No local record, create
                    [toCreate addObject:obj];
                }
            }
        }
    }
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:1];
    [dict setValue:toDelete forKey:@"delete"];
    [dict setValue:toCreate forKey:@"create"];
    [dict setValue:toUpdate forKey:@"update"];
    return dict;
}

#pragma mark - sync action request
// Online server availablity before sending request
- (BOOL)isConnectedToServer
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:
                                    [NSURL URLWithString:@"http://www.google.com/"]];
    
    [request setHTTPMethod:@"HEAD"];
    
    NSHTTPURLResponse *response;
    
    [NSURLConnection sendSynchronousRequest:request
                          returningResponse:&response error:NULL];
    
    return ([response statusCode] == 200) ? YES : NO;
}

// Check connection error, if no error, proceed to handle specific response by returning YES
- (BOOL)handleBasicResponse:(NSHTTPURLResponse *)response withJSONData:(NSData *)data error:(NSError *)error
{
    if ([data length] > 0 && error == nil) {
        NSLog(@"Something was downloaded.");
        return [self statusCheckForResponse:response];
    }
    else if ([data length] == 0 && error == nil) {
        NSLog(@"Nothing was downloaded.");
        [self handleConnectionError:NoDataDownloaded];
    }
    else if (error != nil && error.code == NSURLErrorTimedOut) {
        NSLog(@"Time out");
        [self handleConnectionError:TimeOut];
    }
    else if (error != nil) {
        NSLog(@"Error = %@", error);
        [self handleConnectionError:OtherError];
    }
    return NO;
}

- (void)makeRequestToCheckActivationStausForUser:(TVUser *)user
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ec2-54-219-150-111.us-west-1.compute.amazonaws.com"]];
    [request setHTTPMethod:@"GET"];
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData* data, NSError* error)
     {
         if (user.activated.boolValue == NO) {
             NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
             if ([self handleBasicResponse:httpResponse withJSONData:data error:error]) {
                 // Proceed
                 NSDictionary *dict = [self getDictFromResponse:httpResponse withData:data];
                 if ([[dict valueForKey:@"activated"] isEqualToString:@"true"]) {
                     user.activated = [NSNumber numberWithBool:YES];
                 }
             }
         }
     }];
}

- (BOOL)startResetPasswordWithEmail:(NSString *)email withURLString:(NSString *)URLString
{
    if ([self isConnectedToServer]) {
        // Server is available, start to register
        [self makeRegistrationLoginRequestWithEmail:email password:nil withURLString:URLString];
        return YES;
    } else {
        // Server is not available, sync next time when server is available
        [self handleConnectionError:ServerNotAvailable];
        return NO;
    }
}

- (BOOL)startRegistrationLoginWithEmail:(NSString *)email password:(NSString *)password withURLString:(NSString *)URLString
{
    if ([self isConnectedToServer]) {
        // Server is available, start to register
        [self makeRegistrationLoginRequestWithEmail:email password:password withURLString:URLString];
        return YES;
    } else {
        // Server is not available, sync next time when server is available
        [self handleConnectionError:ServerNotAvailable];
        return NO;
    }
}

- (BOOL)startSyncEntitySet:(NSSet *)entities
     withNewCardController:(TVNewBaseViewController *)controller user:(TVUser *)user
{
    if ([self isConnectedToServer]) {
        // Server is available, start to sync
        [self makeRequestWithEntitySet:entities withNewCardController:controller user:user];
        return YES;
    } else {
        // Server is not available, sync next time when server is available
        [self handleConnectionError:ServerNotAvailable];
        return NO;
    }
}

// Configure registration/login request with respective URLs
- (void)makeRegistrationLoginRequestWithEmail:(NSString *)email password:(NSString *)password withURLString:(NSString *)URLString
{
    NSData *userJSON = [self getUserRegistrationLoginJSONWithEmail:email password:password];
    // Config request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLString]];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:userJSON];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-type"];
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData* data, NSError* error)
     {
         NSHTTPURLResponse *newResponse = (NSHTTPURLResponse *)response;
         if ([self handleBasicResponse:newResponse withJSONData:data error:error]) {
             // Both successful registetration and login request get login response
             [self handleLoginResponse:newResponse withData:data];
         }
     }];
}

// Configure the request operation for dataSync
- (void)makeRequestWithEntitySet:(NSSet *)entities
                              withNewCardController:(TVNewBaseViewController *)controller
                            user:(TVUser *)user
{
    NSData *JSONData;
    if ([entities count] > 0) {
        // This means the request is for data sync
        JSONData = [self getJSONForSyncRequestWithEntityNameSet:entities inContext:user.managedObjectContext user:user];
    }
    if (JSONData) {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://ec2-54-219-150-111.us-west-1.compute.amazonaws.com"]];
        [request setHTTPMethod:@"POST"];
        [request setValue:@"application/json" forHTTPHeaderField:@"Content-type"];
        [request setHTTPBody:JSONData];
        [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData* data, NSError* error)
         {
             NSHTTPURLResponse *newResponse = (NSHTTPURLResponse *)response;
             if ([self handleBasicResponse:newResponse withJSONData:data error:error]) {
                 [self handleDataSyncResponse:newResponse withData:data user:user withNewCardController:controller];
             }
         }];
    }
}

// Get JSON for new user registeration/login request to get a pass
- (NSData *)getUserRegistrationLoginJSONWithEmail:(NSString *)email password:(NSString *)password
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:1];
    [dict setValue:email forKey:@"email"];
    // No password key for password reset request
    if (!password) {
        [dict setValue:password forKey:@"password"];
    }
    return [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
}

// Get JSON for dataSync request
- (NSData *)getJSONForSyncRequestWithEntityNameSet:(NSSet *)entities inContext:(NSManagedObjectContext *)context user:(TVUser *)user
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:1];
    // Email
    [dict setValue:user.email forKey:@"email"];
    // Pass
    [dict setValue:[self getPassFromKeychainEmail:user.email] forKey:@"pass"];
    // HighestVersionNo
    // HighestVersionNo = 0 means local has not been synchronized with server yet.
    [dict setValue:user.highestLastSyncVersionNo forKey:@"highestLastSyncVersionNo"];
    
    // Arries for entities
    NSMutableArray *allRecordArray = [NSMutableArray arrayWithCapacity:1];
    if ([entities containsObject:@"TVCard"]) {
        NSArray *cardArray = [self getArrayAllForSyncRequestWithEntityName:@"TVCard" inContext:context];
        [allRecordArray addObjectsFromArray:cardArray];
    }
    if ([entities containsObject:@"TVTag"]) {
        NSArray *tagArray = [self getArrayAllForSyncRequestWithEntityName:@"TVTag" inContext:context];
        [allRecordArray addObjectsFromArray:tagArray];
    }
    
    if ([allRecordArray count] > 0) {
        // RequestVersionNo check and update in persistence store
        [self assignRequestVersionNoWithUser:user allRecord:allRecordArray];
        [self proceedChangesInContext:context willSendRequest:NO];
        if ([entities containsObject:@"TVCard"]) {
            NSDictionary *cardDict = [self getDictionaryForSyncRequestWithEntityName:@"TVCard" inContext:context];
            [dict setValue:cardDict forKey:@"card"];
        }
        if ([entities containsObject:@"TVTag"]) {
            NSDictionary *tagDict = [self getDictionaryForSyncRequestWithEntityName:@"TVTag" inContext:context];
            [dict setValue:tagDict forKey:@"tag"];
        }
        
        NSLog (@"JSON: %@", dict);
        NSError *error = [[NSError alloc] init];
        return [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    } else {
        // No record to sync, cancel sync action
        return nil;
    }
}

// Get categorized records for one entity in NSDictionary
- (NSDictionary *)getDictionaryForSyncRequestWithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context
{
    NSArray *arrayCreate = [self getArrayForSyncRequestWithEntityName:name forAction:@"create" inContext:context convertNSManagedObjToDict:YES];
    NSArray *arrayUpdate = [self getArrayForSyncRequestWithEntityName:name forAction:@"update" inContext:context convertNSManagedObjToDict:YES];
    NSArray *arrayDelete = [self getArrayForSyncRequestWithEntityName:name forAction:@"delete" inContext:context convertNSManagedObjToDict:YES];
    return [NSDictionary dictionaryWithObjects:@[arrayCreate, arrayUpdate, arrayDelete] forKeys:@[[@"create" stringByAppendingString:name], [@"update" stringByAppendingString:name], [@"delete" stringByAppendingString:name]]];
}

// Get all records for one entity in NSManagedObject
- (NSArray *)getArrayAllForSyncRequestWithEntityName:(NSString *)name inContext:(NSManagedObjectContext *)context
{
    NSArray *arrayCreate = [self getArrayForSyncRequestWithEntityName:name forAction:@"create" inContext:context convertNSManagedObjToDict:NO];
    NSArray *arrayUpdate = [self getArrayForSyncRequestWithEntityName:name forAction:@"update" inContext:context convertNSManagedObjToDict:NO];
    NSArray *arrayDelete = [self getArrayForSyncRequestWithEntityName:name forAction:@"delete" inContext:context convertNSManagedObjToDict:NO];
    NSMutableArray *all = [NSMutableArray arrayWithCapacity:1];
    if ([arrayCreate count] > 0) {
        [all addObjectsFromArray:arrayCreate];
    }
    if ([arrayUpdate count] > 0) {
        [all addObjectsFromArray:arrayUpdate];
    }
    if ([arrayDelete count] > 0) {
        [all addObjectsFromArray:arrayDelete];
    }
    return all;
}

- (NSArray *)getArrayForSyncRequestWithEntityName:(NSString *)name forAction:(NSString *)action inContext:(NSManagedObjectContext *)context convertNSManagedObjToDict:(BOOL)convert
{
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:name];
    NSPredicate *predicateAction = [NSPredicate predicateWithFormat:@"editAction like %@", action];
    [request setPredicate:predicateAction];
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"lastModifiedAtLocal" ascending:YES];
    [request setSortDescriptors:@[sortDescriptor]];
    NSArray *arrayAction = [context executeFetchRequest:request error:nil];
    
    if (convert == YES) {
        NSMutableArray *recordsArray = [NSMutableArray arrayWithCapacity:1];;
        NSEntityDescription *entityDescription = [NSEntityDescription entityForName:name inManagedObjectContext:context];
        for (id obj in arrayAction) {
            NSDictionary *recordDict = [self convertNSManagedObjToDict:obj withEntityDescription:entityDescription];
            [recordsArray addObject:recordDict];
        }
        return recordsArray;
    } else {
        return arrayAction;
    }
}

#pragma mark - record create/update/delete action
- (TVBase *)createRecord:(Class)recordClass recordInResponse:(NSDictionary *)recordInResponse inContext:(NSManagedObjectContext *)context withNewCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user
{
    TVBase *record;
    if ([recordClass isSubclassOfClass:[TVCard class]]) {
        record = (TVCard *)[NSEntityDescription insertNewObjectForEntityForName:@"TVCard" inManagedObjectContext:context];
        [self writeToCard:(TVCard *)record recordInResponse:recordInResponse withController:controller withUser:user];
    }
    if ([recordClass isSubclassOfClass:[TVTag class]]) {
        record = (TVTag *)[NSEntityDescription insertNewObjectForEntityForName:@"TVTag" inManagedObjectContext:context];
        [self writeToTag:(TVTag *)record recordInResponse:recordInResponse withController:anotherController withUser:user];
    }
    if ([recordClass isSubclassOfClass:[TVUser class]]) {
        record = (TVUser *)[NSEntityDescription insertNewObjectForEntityForName:@"TVUser" inManagedObjectContext:context];
        [self writeToUser:(TVUser *)record recordInResponse:recordInResponse];
    }

    if (recordInResponse) {
        // A new record needs to be created on client, the uncommited one should be checked to delete
    } else {
        // A new record is created through local input interface instead of from response
        [self createBefore:record];
    }
    
    return record;
}

// No need to commit the create action since the locally created records will be deleted and new records will created from the response.

- (void)updateRecord:(TVBase *)record recordInResponse:(NSDictionary *)recordInResponse withCardController:(TVNewBaseViewController *)controller withNonCardController:(TVNonCardsBaseViewController *)anotherController user:(TVUser *)user
{
    if ([record isKindOfClass:[TVCard class]]) {
        [self writeToCard:(TVCard *)record recordInResponse:recordInResponse withController:controller withUser:user];
    }
    if ([record isKindOfClass:[TVTag class]]) {
        [self writeToTag:(TVTag *)record recordInResponse:recordInResponse withController:anotherController withUser:user];
    }
    if (recordInResponse) {
        [self updateAfter:record recordInResponse:recordInResponse];
    } else {
        [self updateBefore:record];
    }
}

- (void)commitUpdateRecord:(TVBase *)record recordInResponse:(NSDictionary *)recordInResponse
{
    [self updateAfter:record recordInResponse:recordInResponse];
}

- (void)deleteRecord:(TVBase *)record
{
    [self deleteBefore:record];
}

- (void)commitDeleteRecord:(TVBase *)record
{
    [self deleteAfter:record];
}

- (void)proceedChangesInContext:(NSManagedObjectContext *)context willSendRequest:(BOOL)willSendRequest
{
    TVAppRootViewController *myRootViewController = [self getAppRootViewController];
    myRootViewController.willSendRequest = willSendRequest;
    NSError *error = nil;
    if (![context save:&error]) {
        // Handle the error.
        UIAlertView *myTest = [[UIAlertView alloc] initWithTitle:@"Save error" message:@"failed" delegate:self cancelButtonTitle:@"Got it" otherButtonTitles:nil];
        [myTest show];
    }
}

- (void)writeToCard:(TVCard *)card recordInResponse:(NSDictionary *)recordDict withController:(TVNewBaseViewController *)controller withUser:(TVUser *)user
{
    if (recordDict) {
        [self convertDict:recordDict toNSManagedObj:card];
        [[card mutableSetValueForKey:@"hasTag"] setSet:[NSSet setWithArray:[recordDict valueForKey:@"cardTags"]]];
        // HasTag/collectedBy
        
        if ([[recordDict valueForKey:@"hasTag"] count] > 0) {
            
        }
    } else {
        card.context = controller.myContextView.text;
        card.target = controller.myTargetView.text;
        card.translation = controller.myTranslationView.text;
        card.detail = controller.myDetailView.text;
        card.createdAt = [NSDate date];
        card.collectedAt = [NSDate date];
        card.createdBy = user.email;
        card.sourceLang = user.sourceLang;
        card.targetLang = user.targetLang;
        NSMutableSet *cardTags = [NSMutableSet setWithCapacity:1];
        if ([controller.tagsMultiBaseViewController.myTableViewController.tableView.indexPathsForSelectedRows count] > 0) {
            for (NSIndexPath *path in controller.tagsMultiBaseViewController.myTableViewController.tableView.indexPathsForSelectedRows) {
                TVTag *tag = [controller.tagsMultiBaseViewController.myTableViewController.arrayDataSource objectAtIndex:path.row];
                if ([controller.tagsMultiBaseViewController.myTableViewController.tempAddedRows containsObject:tag]) {
                    // Update the tag
                    tag.createdAt = nil;
                    tag.createdBy = nil;
                    tag.createdAt = [NSDate date];
                    tag.createdBy = user.email;
                }
                [cardTags addObject:tag];
            }
        }
        
        [[card mutableSetValueForKey:@"hasTag"] setSet:cardTags];
    }
}

- (void)writeToTag:(TVTag *)tag recordInResponse:(NSDictionary *)recordDict withController:(TVNonCardsBaseViewController *)controller withUser:(TVUser *)user
{
    if (recordDict) {
        [self convertDict:recordDict toNSManagedObj:tag];
        
        // DO WE NEED TO UPDATE THE CARDS IT HAS??????!!!!
    } else {
        tag.createdAt = [NSDate date];
        tag.tagName = controller.addTextField.text;
        tag.createdBy = user.email;
    }
}

- (void)writeToUser:(TVUser *)user recordInResponse:(NSDictionary *)recordDict
{
    /*
    Creating a new user leads to creating a new TVUser obj from response, all the initial default settings come with the response. The rest modifications on this TVUser record are not sync back to the server.
     */
    if (recordDict) {
        user.email = [recordDict valueForKey:@"email"];
        // Default is YES
        user.isLoggedIn = [recordDict valueForKey:@"isLoggedIn"];
        // Default is collectedAtDAlphabetA
        // Default is YES
        user.needToUpdateRequestVersionNo = [recordDict valueForKey:@"needToUpdateRequestVersionNo"];
        user.sortOption = [recordDict valueForKey:@"sortOption"];
        // Default is the language pair with most cards on server
        user.sourceLang = [recordDict valueForKey:@"sourceLang"];
        user.targetLang = [recordDict valueForKey:@"targetLang"];
        
        // HasCards????????
    }
    // user.currentRequestVersion is edited according to sending request action, not here
    if (user.deviceUUID.length == 0) {
        user.deviceUUID = [recordDict valueForKey:@"deviceUUID"];
    }
}

#pragma mark - common create/update/delete action
// LocalID and serverID are not required at the same time, as long as at least there is one of them to locate the record.
// The same applies to lastModifiedAtLocal and lastModifiedAtServer.
// Create before sync, no lastModifiedServer, serverID, versionNo since client has not sync with server yet.
- (void)createBefore:(TVBase *)base
{
    [self actionBefore:base action:@"create"];
}

- (void)createAfter:(TVBase *)base rootResponse:(NSDictionary *)response
{
    NSNumber *responseRequestVersion = [response valueForKey:@"requestVersion"];
    if (responseRequestVersion.integerValue >= base.requestVersionNo.integerValue) {
        [base.managedObjectContext deleteObject:base];
    } else {
        // Do nothing, let the corresponding response handle it in the future
    }
}

// Update before sync
- (void)updateBefore:(TVBase *)base
{
    [self actionBefore:base action:@"update"];
}

- (void)updateAfter:(TVBase *)base recordInResponse:(NSDictionary *)record
{
    [self actionAfter:base recordInResponse:record];
}

// Delete before sync
- (void)deleteBefore:(TVBase *)base
{
    [self actionBefore:base action:@"delete"];
    if (base.serverID.integerValue == 0 || !base.serverID) {
        // No serverID, must be created after last sync, delete right away
        [self deleteAfter:base];
    }
}

- (void)deleteAfter:(TVBase *)base
{
    // delete instantly
    [base.managedObjectContext deleteObject:base];
}

- (void)actionBefore:(TVBase *)base action:(NSString *)action
{
    base.editAction = action;
    base.lastModifiedAtLocal = [NSDate date];
}

- (void)actionAfter:(TVBase *)base recordInResponse:(NSDictionary *)record
{
    base.editAction = @"";
    base.requestVersionNo = [NSNumber numberWithInteger:0];
    base.lastModifiedAtServer = [record valueForKey:@"lastModifiedAtServer"];
    base.versionNo = [record valueForKey:@"versionNo"];
}

#pragma mark - Load file from supporting files
- (NSArray *)loadLangArray
{
    NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:1];
    NSString * filePath = [[NSBundle mainBundle] pathForResource:@"langListLong" ofType:@"txt"];
    if (filePath) {
        NSString *contents = [NSString stringWithContentsOfFile:filePath encoding:NSUnicodeStringEncoding error:nil];
        NSArray *stringArray = [contents componentsSeparatedByString:@"\r\n"];
        for (NSString *obj in stringArray) {
            if (![obj isEqualToString:@""]) {
                NSString *newObj = [NSString localizedNameOfStringEncoding:NSUnicodeStringEncoding];
                newObj = obj;
                [tempArray addObject:newObj];
            }
        }
    }
    return tempArray;
}

#pragma mark - RequestVersion generator and unique string for device identification
/*
 When to edit requestVersionNo for corresponding records?
 The requestVersionNo is reevaluated while a request is compiled and sent.
 Every edit action means the record is not the same as before, hence the previous version sent with any request needs to be updated. In this case, clear the requestVersionNo in this record to let the next request assign a new requestVersionNo.
 In short, there should be a pair of editAction and requestVersionNo. If any one of the pair is missing, the record is either not needed to be sent or a new requestVersionNo is needed to proceed. Everytime a request is sent, the system elavuate is a new requestVersionNo is needed. If yes, the new one will be assigned to TVUser and records needed.
 */
// This will be triggered when
- (void)switchRequestVersionNoUpdate:(TVUser *)user
{
    if (user.needToUpdateRequestVersionNo.boolValue == YES) {
        user.needToUpdateRequestVersionNo = [NSNumber numberWithBool:NO];
    } else {
        user.needToUpdateRequestVersionNo = [NSNumber numberWithBool:YES];
    }
}

- (void)assignRequestVersionNoWithUser:(TVUser *)user allRecord:(NSArray *)allRecord
{
    // Put all the records need to be sent, in other words, combine cards, tags, etc and create/update/delete
    
    user.needToUpdateRequestVersionNo = [NSNumber numberWithBool:NO];
    
    for (TVBase *record in allRecord) {
        // requestVersionNo is set to be nil if other edit action happens after last request.
        // So nil in requestVersionNo means requestVersionNo for this record needs to be assigned a new value
        if (!record.requestVersionNo) {
            [self switchRequestVersionNoUpdate:user];
            break;
        }
    }
    if (user.needToUpdateRequestVersionNo.boolValue == YES) {
        user.currentRequestVersion = [self generateRequestVersionNo:user.currentRequestVersion];
        for (TVBase *record in allRecord) {
            if (!record.requestVersionNo) {
                record.requestVersionNo = [NSNumber numberWithBool:user.currentRequestVersion.boolValue];
            }
        }
    }
}

- (NSNumber *)generateRequestVersionNo:(NSNumber *)currentRequestVersionNo
{
    NSInteger versionNo;
    if (currentRequestVersionNo.integerValue == 0) {
        versionNo = 1;
    } else {
        versionNo = currentRequestVersionNo.integerValue + 1;
    }
    return [NSNumber numberWithInteger:versionNo];
}

- (NSString *)getUUID
{
    return [[[UIDevice currentDevice] identifierForVendor] UUIDString];
}

@end