//
//  TVSearchViewController.h
//  testView
//
//  Created by Liwei on 2013-07-23.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TVSearchBaseViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (assign, nonatomic) CGSize tempSize;

@end
