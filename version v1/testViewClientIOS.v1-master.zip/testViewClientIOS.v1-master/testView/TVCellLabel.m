//
//  TVCellLabel.m
//  testView
//
//  Created by Liwei on 2013-08-25.
//  Copyright (c) 2013 Liwei. All rights reserved.
//

#import "TVCellLabel.h"

@implementation TVCellLabel

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.numberOfLines = 0;
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
